import { useLocation, useNavigate } from 'react-router-dom';

export const useQueryParams = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const getQueryParam = (param) => {
    const params = new URLSearchParams(location.search);
    return params.get(param);
  };

  const setQueryParam = (param, value) => {
    const params = new URLSearchParams(location.search);
    if (value) {
      params.set(param, value);
    } else {
      params.delete(param);
    }
    navigate(`${location.pathname}?${params.toString()}`, { replace: true });
  };
  
  const getQueryParams = () => {
    return new URLSearchParams(location.search);
  }

  const setQueryParams = (newParams) => {
    const params = new URLSearchParams(location.search);
    Object.entries(newParams).forEach(([key, value]) => {
      if (value) {
        params.set(key, value);
      } else {
        params.delete(key);
      }
    });
    navigate(`${location.pathname}?${params.toString()}`, { replace: true });
  };

  return { getQueryParam, setQueryParam, getQueryParams, setQueryParams };
};