
// import React from 'react';
// import { Routes, Route } from 'react-router-dom';
// import { Toaster } from '@/components/ui/toaster';
// import Navbar from '@/components/layout/Navbar';
// import Footer from '@/components/layout/Footer';
// import WhatsAppFAB from '@/components/WhatsAppFAB';
// import ChatFAB from '@/components/chat/ChatFAB';
// import ChatWidget from '@/components/chat/ChatWidget';
// import Home from '@/pages/Home';
// import Courses from '@/pages/Courses';
// import BrowseCourses from '@/pages/BrowseCourses';
// import CourseDetail from '@/pages/CourseDetail';
// import Workshops from '@/pages/Workshops';
// import Membership from '@/pages/Membership';
// import About from '@/pages/About';
// import Contact from '@/pages/Contact';
// import Policies from '@/pages/Policies';
// import Privacy from '@/pages/Privacy';
// import Refunds from '@/pages/Refunds';
// import ScrollToTop from '@/components/ScrollToTop';
// import Login from '@/pages/auth/Login';
// import Register from '@/pages/auth/Register';
// import InstructorLogin from '@/pages/auth/InstructorLogin';
// import ProtectedRoute from '@/components/auth/ProtectedRoute';
// import Profile from '@/pages/Profile';
// import DashboardLayout from '@/components/layout/DashboardLayout';
// import StudentDashboard from '@/pages/dashboards/StudentDashboard';
// import MyCourses from '@/pages/dashboards/student/MyCourses';
// import Tickets from '@/pages/dashboards/student/Tickets';
// import InstructorDashboard from '@/pages/dashboards/InstructorDashboard';
// import AdminDashboard from '@/pages/dashboards/AdminDashboard';
// import PlaceholderPage from '@/pages/dashboards/PlaceholderPage';
// import Appearance from '@/pages/dashboards/student/Appearance';
// import QuestsPage from '@/pages/dashboards/student/QuestsPage';
// import FriendsPage from '@/pages/dashboards/student/FriendsPage';
// import DrivePage from '@/pages/dashboards/student/DrivePage';
// import LeaderboardPage from '@/pages/dashboards/student/LeaderboardPage';
// import SubscriptionsPage from '@/pages/dashboards/student/SubscriptionsPage';
// import WorkshopsPage from '@/pages/dashboards/student/WorkshopsPage';
// import QuizzesPage from '@/pages/dashboards/student/QuizzesPage';
// import CertificatesPage from '@/pages/dashboards/student/CertificatesPage';
// import WishlistPage from '@/pages/dashboards/student/WishlistPage';
// import OrdersPage from '@/pages/dashboards/student/OrdersPage';
// import ServiceRequestsPage from '@/pages/dashboards/student/ServiceRequestsPage';

// function App() {
//   return (
//     <>
//       <ScrollToTop />
//       <div className="min-h-screen flex flex-col bg-background text-foreground">
//         <Routes>
//           {/* Routes with Navbar and Footer */}
//           <Route
//             path="/*"
//             element={
//               <>
//                 <Navbar />
//                 <main className="flex-1">
//                   <Routes>
//                     <Route path="/" element={<Home />} />
//                     <Route path="/courses" element={<Courses />} />
//                     <Route path="/courses/browse" element={<BrowseCourses />} />
//                     <Route path="/course/:slug" element={<CourseDetail />} />
//                     <Route path="/workshops" element={<Workshops />} />
//                     <Route path="/membership" element={<Membership />} />
//                     <Route path="/about" element={<About />} />
//                     <Route path="/contact" element={<Contact />} />
//                     <Route path="/policies" element={<Policies />} />
//                     <Route path="/privacy" element={<Privacy />} />
//                     <Route path="/refunds" element={<Refunds />} />
//                     <Route path="/login" element={<Login />} />
//                     <Route path="/register" element={<Register />} />
//                     <Route path="/instructor/login" element={<InstructorLogin />} />
//                     {/* Note: Profile is now handled inside dashboard layouts */}
//                   </Routes>
//                 </main>
//                 <Footer />
//                 <WhatsAppFAB />
//                 <ChatFAB />
//               </>
//             }
//           />
          
//           {/* Student Dashboard */}
//           <Route path="/dashboard" element={<ProtectedRoute roles={['student']}><DashboardLayout /></ProtectedRoute>}>
//             <Route index element={<StudentDashboard />} />
//             <Route path="courses" element={<MyCourses />} />
//             <Route path="workshops" element={<WorkshopsPage />} />
//             <Route path="quizzes" element={<QuizzesPage />} />
//             <Route path="quests" element={<QuestsPage />} />
//             <Route path="certificates" element={<CertificatesPage />} />
//             <Route path="friends" element={<FriendsPage />} />
//             <Route path="leaderboard" element={<LeaderboardPage />} />
//             <Route path="wishlist" element={<WishlistPage />} />
//             <Route path="orders" element={<OrdersPage />} />
//             <Route path="subscriptions" element={<SubscriptionsPage />} />
//             <Route path="drive" element={<DrivePage />} />
//             <Route path="terminal" element={<PlaceholderPage title="Terminal" />} />
//             <Route path="tickets" element={<Tickets />} />
//             <Route path="requests" element={<ServiceRequestsPage />} />
//             <Route path="profile" element={<Profile />} />
//             <Route path="appearance" element={<Appearance />} />
//           </Route>

//           {/* Instructor Dashboard */}
//           <Route path="/instructor" element={<ProtectedRoute roles={['instructor']}><DashboardLayout /></ProtectedRoute>}>
//             <Route index element={<InstructorDashboard />} />
//             <Route path="courses" element={<PlaceholderPage title="Manage Courses" />} />
//             <Route path="sessions" element={<PlaceholderPage title="Sessions Manager" />} />
//             <Route path="tickets" element={<PlaceholderPage title="Student Tickets" />} />
//             <Route path="messages" element={<PlaceholderPage title="Messages" />} />
//             <Route path="leaderboard" element={<PlaceholderPage title="Instructor Leaderboard" />} />
//             <Route path="uploads" element={<PlaceholderPage title="Uploads" />} />
//             <Route path="profile" element={<Profile />} />
//             <Route path="appearance" element={<Appearance />} />
//           </Route>

//           {/* Admin Dashboard */}
//           <Route path="/admin" element={<ProtectedRoute roles={['admin']}><DashboardLayout /></ProtectedRoute>}>
//             <Route index element={<AdminDashboard />} />
//             <Route path="courses" element={<PlaceholderPage title="Manage Courses" />} />
//             <Route path="instructors" element={<PlaceholderPage title="Manage Instructors" />} />
//             <Route path="demos" element={<PlaceholderPage title="Manage Demos" />} />
//             <Route path="sessions" element={<PlaceholderPage title="Manage Sessions" />} />
//             <Route path="workshops" element={<PlaceholderPage title="Manage Workshops" />} />
//             <Route path="categories" element={<PlaceholderPage title="Manage Categories" />} />
//             <Route path="pricing" element={<PlaceholderPage title="Manage Pricing" />} />
//             <Route path="coupons" element={<PlaceholderPage title="Manage Coupons" />} />
//             <Route path="orders" element={<OrdersPage />} />
//             <Route path="subscriptions" element={<PlaceholderPage title="Manage Subscriptions" />} />
//             <Route path="reports" element={<PlaceholderPage title="View Reports" />} />
//             <Route path="users" element={<PlaceholderPage title="View Users" />} />
//             <Route path="tickets" element={<PlaceholderPage title="Global Tickets" />} />
//             <Route path="settings" element={<PlaceholderPage title="Site Settings" />} />
//             <Route path="payments" element={<PlaceholderPage title="Payment Settings" />} />
//             <Route path="profile" element={<Profile />} />
//             <Route path="appearance" element={<Appearance />} />
//           </Route>
          
//           {/* General Settings were moved inside specific dashboards to avoid route conflicts */}

//         </Routes>
//         <ChatWidget />
//         <Toaster />
//       </div>
//     </>
//   );
// }

// export default App;
import React from 'react';
import { Routes, Route } from 'react-router-dom';

import { Toaster } from '@/components/ui/toaster';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import WhatsAppFAB from '@/components/WhatsAppFAB';
import ChatFAB from '@/components/chat/ChatFAB';
import ChatWidget from '@/components/chat/ChatWidget';
import ScrollToTop from '@/components/ScrollToTop';

// Public pages
import Home from '@/pages/Home';
import Courses from '@/pages/Courses';
import BrowseCourses from '@/pages/BrowseCourses';
import CourseDetail from '@/pages/CourseDetail';
import Workshops from '@/pages/Workshops';
import Membership from '@/pages/Membership';
import About from '@/pages/About';
import Contact from '@/pages/Contact';
import Policies from '@/pages/Policies';
import Privacy from '@/pages/Privacy';
import Refunds from '@/pages/Refunds';

// Auth
import Login from '@/pages/auth/Login';
import Register from '@/pages/auth/Register';
import InstructorLogin from '@/pages/auth/InstructorLogin'; // optional wrapper to /login?next=/instructor

// Auth guard + dashboards
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import DashboardLayout from '@/components/layout/DashboardLayout';
import Profile from '@/pages/Profile';

// Student area
import StudentDashboard from '@/pages/dashboards/StudentDashboard';
import MyCourses from '@/pages/dashboards/student/MyCourses';
import Tickets from '@/pages/dashboards/student/Tickets';
import Appearance from '@/pages/dashboards/student/Appearance';
import QuestsPage from '@/pages/dashboards/student/QuestsPage';
import FriendsPage from '@/pages/dashboards/student/FriendsPage';
import DrivePage from '@/pages/dashboards/student/DrivePage';
import LeaderboardPage from '@/pages/dashboards/student/LeaderboardPage';
import SubscriptionsPage from '@/pages/dashboards/student/SubscriptionsPage';
import WorkshopsPage from '@/pages/dashboards/student/WorkshopsPage';
import QuizzesPage from '@/pages/dashboards/student/QuizzesPage';
import CertificatesPage from '@/pages/dashboards/student/CertificatesPage';
import WishlistPage from '@/pages/dashboards/student/WishlistPage';
import OrdersPage from '@/pages/dashboards/student/OrdersPage';
import ServiceRequestsPage from '@/pages/dashboards/student/ServiceRequestsPage';

// Instructor area
import InstructorDashboard from '@/pages/dashboards/InstructorDashboard';

// Admin area
import AdminDashboard from '@/pages/dashboards/AdminDashboard';

// NOTE: BrowserRouter is assumed to be in main.jsx (keep it there)

function App() {
  return (
    <>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col bg-background text-foreground">

        <Routes>
          {/* ---------- Public shell (with Navbar/Footer) ---------- */}
          <Route
            path="/*"
            element={
              <>
                <Navbar />
                <main className="flex-1">
                  <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/courses" element={<Courses />} />
                    <Route path="/courses/browse" element={<BrowseCourses />} />
                    {/* Keep your current slug format */}
                    <Route path="/course/:slug" element={<CourseDetail />} />

                    <Route path="/workshops" element={<Workshops />} />
                    <Route path="/membership" element={<Membership />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/policies" element={<Policies />} />
                    <Route path="/privacy" element={<Privacy />} />
                    <Route path="/refunds" element={<Refunds />} />

                    {/* Auth */}
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    {/* Optional: this page should just forward to /login?next=/instructor */}
                    <Route path="/instructor/login" element={<InstructorLogin />} />

                    {/* Public fallback → Home */}
                    <Route path="*" element={<Home />} />
                  </Routes>
                </main>
                <Footer />
                <WhatsAppFAB />
                <ChatFAB />
              </>
            }
          />

          {/* ---------- Student Dashboard ---------- */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute roles={['student']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<StudentDashboard />} />
            <Route path="courses" element={<MyCourses />} />
            <Route path="workshops" element={<WorkshopsPage />} />
            <Route path="quizzes" element={<QuizzesPage />} />
            <Route path="quests" element={<QuestsPage />} />
            <Route path="certificates" element={<CertificatesPage />} />
            <Route path="friends" element={<FriendsPage />} />
            <Route path="leaderboard" element={<LeaderboardPage />} />
            <Route path="wishlist" element={<WishlistPage />} />
            <Route path="orders" element={<OrdersPage />} />
            <Route path="subscriptions" element={<SubscriptionsPage />} />
            <Route path="drive" element={<DrivePage />} />
            <Route path="terminal" element={<Placeholder title="Terminal" />} />
            <Route path="tickets" element={<Tickets />} />
            <Route path="requests" element={<ServiceRequestsPage />} />
            <Route path="profile" element={<Profile />} />
            <Route path="appearance" element={<Appearance />} />
          </Route>

          {/* ---------- Instructor Dashboard ---------- */}
          <Route
            path="/instructor"
            element={
              <ProtectedRoute roles={['instructor']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<InstructorDashboard />} />
            <Route path="courses" element={<Placeholder title="Manage Courses" />} />
            <Route path="sessions" element={<Placeholder title="Sessions Manager" />} />
            <Route path="tickets" element={<Placeholder title="Student Tickets" />} />
            <Route path="messages" element={<Placeholder title="Messages" />} />
            <Route path="leaderboard" element={<Placeholder title="Instructor Leaderboard" />} />
            <Route path="uploads" element={<Placeholder title="Uploads" />} />
            <Route path="profile" element={<Profile />} />
            <Route path="appearance" element={<Appearance />} />
          </Route>

          {/* ---------- Admin Dashboard ---------- */}
          <Route
            path="/admin"
            element={
              <ProtectedRoute roles={['admin']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<AdminDashboard />} />
            <Route path="courses" element={<Placeholder title="Manage Courses" />} />
            <Route path="instructors" element={<Placeholder title="Manage Instructors" />} />
            <Route path="demos" element={<Placeholder title="Manage Demos" />} />
            <Route path="sessions" element={<Placeholder title="Manage Sessions" />} />
            <Route path="workshops" element={<Placeholder title="Manage Workshops" />} />
            <Route path="categories" element={<Placeholder title="Manage Categories" />} />
            <Route path="pricing" element={<Placeholder title="Manage Pricing" />} />
            <Route path="coupons" element={<Placeholder title="Manage Coupons" />} />
            <Route path="orders" element={<OrdersPage />} />
            <Route path="subscriptions" element={<Placeholder title="Manage Subscriptions" />} />
            <Route path="reports" element={<Placeholder title="View Reports" />} />
            <Route path="users" element={<Placeholder title="View Users" />} />
            <Route path="tickets" element={<Placeholder title="Global Tickets" />} />
            <Route path="settings" element={<Placeholder title="Site Settings" />} />
            <Route path="payments" element={<Placeholder title="Payment Settings" />} />
            <Route path="profile" element={<Profile />} />
            <Route path="appearance" element={<Appearance />} />
          </Route>
        </Routes>

        {/* Always-on widgets */}
        <ChatWidget />
        <Toaster />
      </div>
    </>
  );
}

/** Local tiny placeholder so App compiles even if you haven't created the page yet */
function Placeholder({ title = 'Coming Soon' }) {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold">{title}</h1>
      <p className="text-muted-foreground mt-2">This page is a placeholder.</p>
    </div>
  );
}

export default App;
