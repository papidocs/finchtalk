// ============================================================================
// file: src/context/AuthContext.jsx
// ============================================================================

import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';


export default function AdminRoute() {
const { user, loading } = useAuth();
const location = useLocation();


if (loading) return null; // or a spinner


if (!user || user.role !== 'admin') {
const next = encodeURIComponent(location.pathname + location.search);
return <Navigate to={`/signin?next=${next}`} replace />;
}


return <Outlet />;
}