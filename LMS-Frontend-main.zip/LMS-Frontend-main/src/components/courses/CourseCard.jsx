import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Clock, User, Video, ArrowRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const CourseCard = ({ course, index }) => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleRequestDemo = (e) => {
    e.stopPropagation();
    window.open('https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20help%20choosing%20a%20course%20and%20booking%20a%20demo.', '_blank');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-xl hover:border-primary/50 transition-all group"
    >
      <div className="relative h-48 bg-muted overflow-hidden cursor-pointer" onClick={() => navigate(`/course/${course.slug}`)}>
        <img 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
          alt={`${course.title} course cover image`}
         src={course.coverUrl || "https://images.unsplash.com/photo-1643101807331-21a4a3f081d5"} />
        {course.badge && (
          <div className="absolute top-4 right-4 px-3 py-1 bg-accent text-accent-foreground text-xs font-semibold rounded-full shadow-lg">
            {course.badge}
          </div>
        )}
      </div>

      <div className="p-6">
        <div className="flex flex-wrap gap-2 mb-3">
          <span className="px-3 py-1 bg-primary/10 text-primary text-xs rounded-full font-medium">
            {course.category}
          </span>
          <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">
            {course.level}
          </span>
        </div>

        <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors cursor-pointer" onClick={() => navigate(`/course/${course.slug}`)}>
          {course.title}
        </h3>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2 h-[40px]">
          {course.summary}
        </p>

        <div className="space-y-2 mb-6">
          <div className="flex items-center text-sm text-muted-foreground">
            <Clock className="w-4 h-4 mr-2 text-primary" />
            <span>{course.duration}</span>
          </div>
          <div className="flex items-center text-sm text-muted-foreground">
            <User className="w-4 h-4 mr-2 text-primary" />
            <span>{course.trainer || 'Expert Instructor'}</span>
          </div>
          {course.hasRecordings && (
            <div className="flex items-center text-sm text-muted-foreground">
              <Video className="w-4 h-4 mr-2 text-primary" />
              <span>Recording Available</span>
            </div>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={() => navigate(`/course/${course.slug}`)}
          >
            Course Details
          </Button>
          <Button 
            className="flex-1"
            onClick={handleRequestDemo}
          >
            Request Demo
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default CourseCard;