import React from 'react';
import { motion } from 'framer-motion';
import { Bot, X } from 'lucide-react';
import { useChat } from '@/context/ChatContext';

const ChatFAB = () => {
  const { isOpen, toggleChat } = useChat();

  return (
    <motion.button
      onClick={toggleChat}
      className="fixed bottom-24 right-6 z-50 w-14 h-14 bg-primary hover:bg-primary/90 rounded-full shadow-lg flex items-center justify-center group"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1.2 }}
      aria-label={isOpen ? 'Close Chat' : 'Open Chat Assistant'}
    >
      <motion.div
        animate={{ rotate: isOpen ? 180 : 0, scale: isOpen ? 1 : 1 }}
        transition={{ duration: 0.3 }}
      >
        {isOpen ? <X className="w-7 h-7 text-white" /> : <Bot className="w-7 h-7 text-white" />}
      </motion.div>
    </motion.button>
  );
};

export default ChatFAB;