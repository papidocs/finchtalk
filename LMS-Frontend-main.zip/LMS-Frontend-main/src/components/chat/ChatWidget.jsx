import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useChat } from '@/context/ChatContext';
import { Send, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const ChatWidget = () => {
  const { isOpen, messages, sendMessage } = useChat();
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = () => {
    if (inputValue.trim()) {
      sendMessage({ type: 'text', text: inputValue });
      setInputValue('');
    }
  };

  const handleButtonClick = (button) => {
    sendMessage({ type: 'button', text: button.text, payload: button.payload });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.9 }}
          transition={{ duration: 0.3, ease: 'easeInOut' }}
          className="fixed bottom-24 right-6 z-40 w-[90vw] max-w-sm h-[70vh] max-h-[600px] bg-card/80 backdrop-blur-xl border border-border rounded-2xl shadow-2xl flex flex-col"
        >
          {/* Header */}
          <header className="p-4 border-b border-border flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <Bot className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h3 className="font-semibold">Finch AI Assistant</h3>
              <p className="text-xs text-muted-foreground">Ready to help!</p>
            </div>
          </header>

          {/* Messages */}
          <div className="flex-1 p-4 overflow-y-auto scrollbar-thin">
            <div className="space-y-4">
              {messages.map((msg, index) => (
                <div key={index} className={`flex ${msg.sender === 'bot' ? 'justify-start' : 'justify-end'}`}>
                  <div className={`p-3 rounded-xl max-w-xs ${msg.sender === 'bot' ? 'bg-muted text-muted-foreground' : 'bg-primary text-primary-foreground'}`}>
                    <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                    {msg.buttons && msg.buttons.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {msg.buttons.map((btn, i) => (
                          <Button key={i} variant="secondary" size="sm" className="w-full text-left justify-start" onClick={() => handleButtonClick(btn)}>
                            {btn.text}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </div>

          {/* Input */}
          <footer className="p-4 border-t border-border">
            <div className="flex items-center gap-2">
              <Input
                type="text"
                placeholder="Type your message..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                className="flex-1"
              />
              <Button size="icon" onClick={handleSend} disabled={!inputValue.trim()}>
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </footer>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ChatWidget;