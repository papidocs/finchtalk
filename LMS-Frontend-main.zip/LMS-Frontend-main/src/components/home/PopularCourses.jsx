import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Cloud, Database, Code, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const CourseCard = ({ course, navigate }) => (
  <div
    style={{ '--marquee-gap': '1.5rem' }}
    className={cn(
        "group relative bg-card border rounded-2xl p-4 hover:shadow-xl hover:border-primary/50 transition-all cursor-pointer",
        "flex-shrink-0 w-[calc(100%/1-1.5rem)] sm:w-[calc(100%/2-1.5rem)] md:w-[calc(100%/3-1.5rem)] lg:w-[calc(100%/4-1.5rem)]"
    )}
    onClick={() => navigate(`/course/${course.slug}`)}
  >
    <div className="flex flex-col h-full">
        <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${course.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
          <course.icon className="w-6 h-6 text-white" />
        </div>
        <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors flex-grow">
          {course.title}
        </h3>
        <div className="flex items-center text-primary text-sm font-medium group-hover:translate-x-1 transition-transform mt-auto">
          Learn More <ArrowRight className="w-4 h-4 ml-1" />
        </div>
    </div>
  </div>
);

const PopularCourses = () => {
  const navigate = useNavigate();

  const courses = [
    { id: 1, title: 'AWS Cloud Practitioner', slug: 'aws-cloud-practitioner', icon: Cloud, color: 'from-blue-500 to-cyan-500' },
    { id: 2, title: 'DevOps with Docker & Kubernetes', slug: 'devops-docker-kubernetes', icon: Code, color: 'from-purple-500 to-pink-500' },
    { id: 3, title: 'Data Engineering Fundamentals', slug: 'data-engineering-fundamentals', icon: Database, color: 'from-orange-500 to-red-500' },
    { id: 4, title: 'Advanced Generative AI', slug: 'advanced-generative-ai', icon: Code, color: 'from-green-500 to-teal-500' },
    { id: 5, title: 'Cyber Security Essentials', slug: 'cyber-security-essentials', icon: Cloud, color: 'from-red-500 to-yellow-500' },
    { id: 6, title: 'React for Production', slug: 'react-for-production', icon: Code, color: 'from-sky-500 to-indigo-500' },
    { id: 7, title: 'Azure Fundamentals AZ-900', slug: 'azure-fundamentals', icon: Cloud, color: 'from-sky-600 to-blue-700' },
    { id: 8, title: 'Python for Data Science', slug: 'python-data-science', icon: Code, color: 'from-yellow-400 to-amber-500' },
  ];

  const duplicatedCourses = [...courses, ...courses];

  return (
    <section>
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-8"
        >
          <p className="text-sm font-semibold uppercase text-primary mb-2">Learn by doing</p>
          <h2 className="text-3xl md:text-4xl font-semibold leading-tight">Courses</h2>
        </motion.div>

        <div className="w-full overflow-hidden relative group/marquee">
            <div className="flex gap-6 animate-scroll-x group-hover/marquee:[animation-play-state:paused]">
                {duplicatedCourses.map((course, index) => (
                    <CourseCard key={`${course.id}-${index}`} course={course} navigate={navigate} />
                ))}
            </div>
            <div className="absolute top-0 bottom-0 left-0 w-24 bg-gradient-to-r from-background to-transparent pointer-events-none"></div>
            <div className="absolute top-0 bottom-0 right-0 w-24 bg-gradient-to-l from-background to-transparent pointer-events-none"></div>
        </div>

        <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mt-8"
        >
          <Button 
            onClick={() => navigate('/courses/browse')}
            variant="link"
            className="group text-base"
          >
            View all courses
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </motion.div>
    </section>
  );
};

export default PopularCourses;