import React from 'react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';

const WorkshopTickerRow = ({ workshop, handleWaitlist }) => (
    <div
        style={{ '--ticker-gap': '2rem' }}
        className="group flex items-center justify-between p-4 border-b h-20 cursor-pointer"
        onClick={() => handleWaitlist(workshop.title)}
    >
        <div className="flex-1">
            <p className="font-semibold text-base group-hover:text-primary transition-colors">{workshop.title}</p>
            <p className="text-sm text-muted-foreground">{workshop.meta}</p>
        </div>
        <span className="text-xs font-semibold uppercase text-accent tracking-wider hidden sm:block">Upcoming</span>
    </div>
);

const UpcomingWorkshops = () => {
  const { toast } = useToast();

  const workshops = [
    { id: 1, title: 'Terraform Infrastructure as Code', meta: 'Dec 15, 2025 • 12 seats left' },
    { id: 2, title: 'Python for Data Analysis', meta: 'Dec 22, 2025 • 8 seats left' },
    { id: 3, title: 'CI/CD with GitHub Actions', meta: 'Jan 5, 2026 • 15 seats left' },
    { id: 4, title: 'Building LLM Apps with LangChain', meta: 'Jan 12, 2026 • 10 seats left' },
    { id: 5, title: 'Kubernetes Deep Dive', meta: 'Jan 19, 2026 • 5 seats left' },
    { id: 6, title: 'Advanced Prompt Engineering', meta: 'Feb 2, 2026 • 18 seats left' },
    { id: 7, title: 'Ethical Hacking & Pentesting', meta: 'Feb 9, 2026 • 7 seats left' },
  ];

  const duplicatedWorkshops = [...workshops, ...workshops];

  const handleWaitlist = (title) => {
    toast({
      title: `Joined Waitlist for ${title}`,
      description: "We'll notify you when registration opens! 🚀",
    });
  };

  return (
    <section>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-8"
        >
          <h2 className="text-3xl md:text-4xl font-semibold leading-tight">
            Upcoming Workshops
          </h2>
          <p className="text-muted-foreground mt-2">Live, interactive sessions. Seats are limited.</p>
        </motion.div>

        <div className="h-[72vh] max-h-[560px] w-full overflow-hidden relative group/ticker border rounded-2xl">
            <div className="flex flex-col animate-scroll-y group-hover/ticker:[animation-play-state:paused]">
                {duplicatedWorkshops.map((workshop, index) => (
                    <WorkshopTickerRow key={`${workshop.id}-${index}`} workshop={workshop} handleWaitlist={handleWaitlist} />
                ))}
            </div>
            <div className="absolute top-0 left-0 w-full h-16 bg-gradient-to-b from-background to-transparent pointer-events-none"></div>
            <div className="absolute bottom-0 left-0 w-full h-16 bg-gradient-to-t from-background to-transparent pointer-events-none"></div>
        </div>
    </section>
  );
};

export default UpcomingWorkshops;