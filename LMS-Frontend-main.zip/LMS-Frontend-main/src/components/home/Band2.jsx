import React from 'react';
import PopularCourses from '@/components/home/PopularCourses';
import DemosThisWeek from '@/components/home/DemosThisWeek';

const Band2 = () => {
  return (
    <div className="py-20">
      <div className="container mx-auto max-w-7xl px-6 space-y-14">
        <PopularCourses />
        <div className="h-8" />
        <DemosThisWeek />
      </div>
    </div>
  );
};

export default Band2;