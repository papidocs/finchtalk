import React from 'react';
import { motion } from 'framer-motion';
import { Video, FlaskConical, BookOpen, CreditCard } from 'lucide-react';

const WhyFinchtalk = () => {
  const features = [
    {
      icon: Video,
      title: 'Live instruction',
      description: 'Interactive Zoom sessions with expert trainers who answer your questions in real-time'
    },
    {
      icon: FlaskConical,
      title: 'Lab-first learning',
      description: 'Hands-on cloud labs where you practice real-world scenarios and build confidence'
    },
    {
      icon: BookOpen,
      title: 'Recordings library',
      description: 'Access all session recordings anytime to review concepts at your own pace'
    },
    {
      icon: CreditCard,
      title: 'Flexible memberships',
      description: 'Memberships with ₹0 checkout on covered items—learn more without barriers'
    }
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-semibold mb-4">Why Finchtalk</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            We combine live instruction, practical labs, and flexible learning to help you succeed
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-card border border-border rounded-xl p-6 hover:shadow-lg hover:border-primary/50 transition-all group"
            >
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyFinchtalk;