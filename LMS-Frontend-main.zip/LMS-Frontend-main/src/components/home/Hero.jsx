import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sparkles, Video, BookOpen, FlaskConical } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Hero = () => {
  const navigate = useNavigate();

  const handleDemoClick = () => {
    window.open('https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20help%20choosing%20a%20course%20and%20booking%20a%20demo.', '_blank');
  };

  const handleWhatsAppClick = () => {
    window.open('https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20help%20choosing%20a%20course%20and%20booking%20a%20demo.', '_blank');
  };

  return (
    <section className="relative overflow-hidden bg-background pt-24 md:pt-32">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10" />
      
      <div className="container mx-auto px-4 relative z-10 pb-16 md:pb-24">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-semibold leading-tight">
              Learn Faster with{' '}
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Live Zoom + Hands-On Labs
              </span>
            </h1>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Book a live demo, browse courses, or chat on WhatsApp—get learning the practical way.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <Button 
              onClick={handleDemoClick}
              size="lg" 
              className="bg-primary hover:bg-primary/90 text-base md:text-lg px-8 py-6 group"
            >
              <Sparkles className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform" />
              Chat to Book a Live Demo
            </Button>
            <Button 
              onClick={() => navigate('/courses/browse')}
              size="lg" 
              variant="outline" 
              className="text-base md:text-lg px-8 py-6"
            >
              Browse Courses
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex flex-wrap justify-center gap-6 pt-8"
          >
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Video className="w-5 h-5 text-primary" />
              <span>Live on Zoom</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <BookOpen className="w-5 h-5 text-primary" />
              <span>Recording after session</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <FlaskConical className="w-5 h-5 text-primary" />
              <span>Hands-on labs</span>
            </div>
          </motion.div>
        </div>
      </div>
      <div className="container mx-auto px-4 relative z-10 pb-20 md:pb-32">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="max-w-5xl mx-auto"
        >
          <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-border/50 aspect-video bg-muted">
            <img
              src="https://images.unsplash.com/photo-1573165231977-3f0e27806045?q=80&w=2069&auto=format&fit=crop"
              alt="Students learning in a modern, collaborative office environment"
              className="w-full h-full object-cover"
              loading="eager"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;