import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

const DemoCard = ({ demo, handleAction }) => (
    <div
        style={{ '--marquee-gap': '1.5rem' }}
        className={cn(
            "group relative bg-card border rounded-2xl p-6 hover:shadow-xl hover:border-primary/50 transition-all cursor-pointer",
            "flex flex-col flex-shrink-0 w-[calc(100%-1.5rem)] sm:w-[calc(50%-1.5rem)] md:w-[calc(33.333%-1.5rem)]"
        )}
        onClick={() => handleAction("Info")}
    >
        <h3 className="text-lg font-semibold mb-3 flex-grow group-hover:text-primary transition-colors">{demo.title}</h3>
        <p className="text-sm text-muted-foreground mb-4">{demo.date} • {demo.time} • {demo.trainer}</p>
        
        <div className="flex gap-3 mt-auto">
            <Button onClick={(e) => { e.stopPropagation(); handleAction("Join"); }} className="flex-1">Join</Button>
            <Button onClick={(e) => { e.stopPropagation(); handleAction("Info"); }} variant="secondary" className="flex-1">Info</Button>
        </div>
    </div>
);

const DemosThisWeek = () => {
    const { toast } = useToast();
    const navigate = useNavigate();

    const demos = [
        {
            id: 1,
            title: 'Live Q&A: AWS Solutions Architect Path',
            date: 'Nov 04',
            time: '7:00 PM IST',
            trainer: 'Instructor Ina',
        },
        {
            id: 2,
            title: 'Intro to Kubernetes for Developers',
            date: 'Nov 06',
            time: '8:30 PM IST',
            trainer: 'Teacher Demo',
        },
        {
            id: 3,
            title: 'Fireside Chat: The Future of Generative AI',
            date: 'Nov 07',
            time: '6:00 PM IST',
            trainer: 'Industry Experts',
        },
        {
            id: 4,
            title: 'Deep Dive into Terraform State',
            date: 'Nov 08',
            time: '7:30 PM IST',
            trainer: 'DevOps Pro',
        },
        {
            id: 5,
            title: 'Building Your First RAG Pipeline',
            date: 'Nov 09',
            time: '8:00 PM IST',
            trainer: 'AI Specialist',
        }
    ];

    const duplicatedDemos = [...demos, ...demos];
    
    const handleAction = (action) => {
        toast({
            title: `Action: ${action}`,
            description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        });
    }

    return (
        <section>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="flex justify-between items-end mb-8"
            >
                <div>
                  <h2 className="text-3xl md:text-4xl font-semibold leading-tight">Demos This Week</h2>
                  <p className="text-muted-foreground mt-2">Join live sessions with our expert instructors.</p>
                </div>
                 <Button onClick={() => handleAction("See all demos")} variant="link" className="hidden md:inline-flex group">
                    See all demos <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                 </Button>
            </motion.div>

            <div className="w-full overflow-hidden relative group/marquee">
                <div className="flex gap-6 animate-scroll-x group-hover/marquee:[animation-play-state:paused]">
                    {duplicatedDemos.map((demo, index) => (
                        <DemoCard key={`${demo.id}-${index}`} demo={demo} handleAction={handleAction} />
                    ))}
                </div>
                <div className="absolute top-0 bottom-0 left-0 w-24 bg-gradient-to-r from-background to-transparent pointer-events-none"></div>
                <div className="absolute top-0 bottom-0 right-0 w-24 bg-gradient-to-l from-background to-transparent pointer-events-none"></div>
            </div>

             <div className="text-center mt-6 md:hidden">
                <Button onClick={() => handleAction("See all demos")} variant="link" className="group">
                    See all demos <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                 </Button>
             </div>
        </section>
    );
};

export default DemosThisWeek;