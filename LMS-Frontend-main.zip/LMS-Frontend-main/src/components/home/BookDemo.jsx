import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sparkles, MessageCircle } from 'lucide-react';

const BookDemo = () => {
  const handleDemoClick = () => {
    window.open('https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20help%20choosing%20a%20course%20and%20booking%20a%20demo.', '_blank');
  };

  return (
    <section className="py-20 bg-gradient-to-br from-primary/10 via-transparent to-accent/10">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto bg-card border border-border rounded-2xl p-8 md:p-12 text-center"
        >
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center mx-auto mb-6">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          
          <h2 className="text-3xl md:text-4xl font-semibold mb-4">Book a Demo</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            See It in Action. Our AI assistant proposes a slot and emails a Zoom invite.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={handleDemoClick}
              size="lg" 
              className="bg-primary hover:bg-primary/90 group"
            >
              <MessageCircle className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
              Chat to Book a Live Demo
            </Button>
          </div>

          <p className="text-sm text-muted-foreground mt-6">
            No commitment required • Get personalized course recommendations
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default BookDemo;