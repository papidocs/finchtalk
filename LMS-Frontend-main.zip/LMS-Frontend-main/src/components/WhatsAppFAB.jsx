import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const WhatsAppFAB = () => {
  const { toast } = useToast();

  const handleClick = () => {
    window.open('https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20help%20choosing%20a%20course%20and%20booking%20a%20demo.', '_blank');
    toast({
      title: "Opening WhatsApp",
      description: "Redirecting you to WhatsApp chat...",
    });
  };

  return (
    <motion.button
      onClick={handleClick}
      className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-[#25D366] hover:bg-[#20BA5A] rounded-full shadow-lg flex items-center justify-center group"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1 }}
    >
      <MessageCircle className="w-7 h-7 text-white" />
      <motion.div
        className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full"
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ repeat: Infinity, duration: 2 }}
      />
    </motion.button>
  );
};

export default WhatsAppFAB;