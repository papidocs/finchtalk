
import React from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import {
  Home, BookOpen, Layers, Award, Users, BarChart2, Heart, ShoppingCart, CreditCard, Folder, Terminal, LifeBuoy, HelpCircle,
  UserCircle, Briefcase, FileText, Calendar, Upload, ChevronsLeft, ChevronsRight, Search, Zap, LogOut, MessageSquare,
  Shield, Tag, BarChart, Users2, Cog, CreditCard as CreditCardIcon, Video, GitBranch, Palette
} from 'lucide-react';
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';


const SidebarNavLink = ({ to, icon: Icon, children, isCollapsed, closeMobileMenu, badge }) => {
  const location = useLocation();
  const baseDashboardPath = `/${location.pathname.split('/')[1]}`;
  
  const isActive = location.pathname === to || (to !== baseDashboardPath && location.pathname.startsWith(to));

  const handleClick = () => {
    if (closeMobileMenu) {
      closeMobileMenu();
    }
  };

  return (
    <NavLink
      to={to}
      onClick={handleClick}
      end={to === baseDashboardPath}
      className={cn(
        "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 relative",
        isActive ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted/50 hover:text-foreground",
        isCollapsed && "justify-center"
      )}
    >
      <Icon className="h-5 w-5 shrink-0" />
      <span className={cn("transition-opacity duration-200 whitespace-nowrap", isCollapsed ? "opacity-0 w-0" : "opacity-100 w-auto")}>
        {children}
      </span>
      {badge > 0 && !isCollapsed && (
          <span className="ml-auto bg-accent text-accent-foreground text-xs font-bold px-2 py-0.5 rounded-full">{badge}</span>
      )}
      {isActive && !isCollapsed && <div className="absolute left-0 h-6 w-1 bg-primary rounded-r-full" />}
    </NavLink>
  );
};


const Sidebar = ({ isOpen, toggleSidebar, isMobile = false, closeMobileMenu }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const getInitials = (name = '') => name?.split(' ').map(n => n[0]).join('') || '';

  const studentNav = [
    { title: "Learn", icon: BookOpen, items: [
      { name: "My Learning", to: "/dashboard", icon: Home, badge: 0 },
      { name: "Courses", to: "/dashboard/courses", icon: BookOpen, badge: 0 },
      { name: "Workshops", to: "/dashboard/workshops", icon: Layers, badge: 2 },
      { name: "Quizzes", to: "/dashboard/quizzes", icon: FileText, badge: 0 },
      { name: "Quests", to: "/dashboard/quests", icon: Zap, badge: 3 },
      { name: "Certificates", to: "/dashboard/certificates", icon: Award, badge: 0 },
    ]},
    { title: "Social", icon: Users, items: [
      { name: "Friends", to: "/dashboard/friends", icon: Users, badge: 5 },
      { name: "Leaderboard", to: "/dashboard/leaderboard", icon: BarChart2, badge: 0 },
    ]},
    { title: "Commerce", icon: ShoppingCart, items: [
      { name: "Wishlist", to: "/dashboard/wishlist", icon: Heart, badge: 0 },
      { name: "Orders", to: "/dashboard/orders", icon: ShoppingCart, badge: 0 },
      { name: "Subscriptions", to: "/dashboard/subscriptions", icon: CreditCard, badge: 0 },
    ]},
    { title: "Workspace", icon: Folder, items: [
      { name: "Drive", to: "/dashboard/drive", icon: Folder, badge: 0 },
      { name: "Terminal", to: "/dashboard/terminal", icon: Terminal, badge: 0 },
    ]},
    { title: "Support", icon: LifeBuoy, items: [
      { name: "Support Tickets", to: "/dashboard/tickets", icon: LifeBuoy, badge: 1 },
      { name: "Service Requests", to: "/dashboard/requests", icon: HelpCircle, badge: 0 },
    ]},
  ];

  const instructorNav = [
    { title: "Instructor", icon: Briefcase, items: [
      { name: "Overview", to: "/instructor", icon: Home, badge: 0 },
      { name: "Courses", to: "/instructor/courses", icon: BookOpen, badge: 0 },
      { name: "Sessions", to: "/instructor/sessions", icon: Calendar, badge: 0 },
      { name: "Tickets", to: "/instructor/tickets", icon: LifeBuoy, badge: 4 },
      { name: "Messages", to: "/instructor/messages", icon: MessageSquare, badge: 8 },
      { name: "Leaderboard", to: "/instructor/leaderboard", icon: BarChart2, badge: 0 },
      { name: "Uploads", to: "/instructor/uploads", icon: Upload, badge: 0 },
    ]}
  ];

  const adminNav = [
      { title: "Admin", icon: Shield, items: [
          { name: "Dashboard", to: "/admin", icon: Home, badge: 0 },
      ]},
      { title: "Content", icon: BookOpen, items: [
          { name: "Courses", to: "/admin/courses", icon: BookOpen, badge: 0 },
          { name: "Instructors", to: "/admin/instructors", icon: Briefcase, badge: 0 },
          { name: "Demos", to: "/admin/demos", icon: Video, badge: 0 },
          { name: "Sessions", to: "/admin/sessions", icon: Calendar, badge: 0 },
          { name: "Workshops", to: "/admin/workshops", icon: Layers, badge: 0 },
          { name: "Categories", to: "/admin/categories", icon: GitBranch, badge: 0 },
      ]},
      { title: "Commerce", icon: ShoppingCart, items: [
          { name: "Pricing", to: "/admin/pricing", icon: Tag, badge: 0 },
          { name: "Coupons", to: "/admin/coupons", icon: Tag, badge: 0 },
          { name: "Orders", to: "/admin/orders", icon: ShoppingCart, badge: 0 },
          { name: "Subscriptions", to: "/admin/subscriptions", icon: CreditCardIcon, badge: 0 },
          { name: "Reports", to: "/admin/reports", icon: BarChart, badge: 0 },
      ]},
      { title: "People", icon: Users2, items: [
          { name: "Users", to: "/admin/users", icon: Users2, badge: 0 },
          { name: "Tickets", to: "/admin/tickets", icon: LifeBuoy, badge: 12 },
      ]},
      { title: "Settings", icon: Cog, items: [
          { name: "Site Settings", to: "/admin/settings", icon: Cog, badge: 0 },
          { name: "Payments", to: "/admin/payments", icon: CreditCard, badge: 0 },
      ]},
  ];
  
  const settingsNav = [
    { title: "Settings", icon: Cog, items: [
      { name: "Profile", to: `/${user?.role === 'student' ? 'dashboard' : user?.role}/profile`, icon: UserCircle, badge: 0 },
      { name: "Appearance", to: `/${user?.role === 'student' ? 'dashboard' : user?.role}/appearance`, icon: Palette, badge: 0 },
    ]}
  ];

  const isInstructorView = location.pathname.startsWith('/instructor');
  const isAdminView = location.pathname.startsWith('/admin');
  
  let navSections;
  if (isAdminView) {
      navSections = adminNav;
  } else if (isInstructorView) {
      navSections = instructorNav;
  } else {
      navSections = studentNav;
  }
  
  navSections = [...navSections, ...settingsNav];


  const isCollapsed = !isOpen && !isMobile;

  return (
    <motion.div
      animate={{ width: isCollapsed ? 72 : 248 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className={cn(
        "h-full flex flex-col bg-background border-r border-border overflow-y-auto scrollbar-thin",
        isMobile ? "w-full" : "fixed"
      )}
    >
      <div className="flex-1 px-3 py-4 space-y-4">
        <div className={cn("flex items-center gap-2 px-2 mb-4 h-16", isCollapsed ? "justify-center" : "justify-between")}>
          <Link to="/" className={cn("flex items-center gap-2", isCollapsed && "hidden")}>
             <img src="https://horizons-cdn.hostinger.com/7c77bb82-84e0-4421-92d7-3bd545a3adf8/be5fb749c9e12941c9958679d295b1b4.png" alt="Finchtalk Logo" className="h-10 md:h-12" />
          </Link>
          <Link to="/" className={cn("flex items-center justify-center", !isCollapsed && "hidden")}>
             <img src="https://horizons-cdn.hostinger.com/7c77bb82-84e0-4421-92d7-3bd545a3adf8/0b45614210ca10d1cec6743199593e87.png" alt="Finchtalk Icon" className="h-8 w-8" />
          </Link>
        </div>

        <div className="px-1">
          <Button variant="ghost" className={cn("w-full justify-start", isCollapsed && "justify-center")}>
            <Search className="h-5 w-5"/>
            {!isCollapsed && <span className="ml-2">Search</span>}
          </Button>
        </div>

        <Accordion type="multiple" defaultValue={navSections.map(i => i.title)} className="w-full">
          {navSections.map(section => (
            <AccordionItem key={section.title} value={section.title} className="border-none">
              <AccordionTrigger className={cn("hover:no-underline text-xs uppercase text-muted-foreground px-3 py-2", isCollapsed && "justify-center")}>
                { isCollapsed ? <section.icon className="h-5 w-5" /> : section.title }
              </AccordionTrigger>
              <AccordionContent className="pb-2 space-y-1">
                {section.items.map(item => (
                   <SidebarNavLink key={item.to} to={item.to} icon={item.icon} isCollapsed={isCollapsed} closeMobileMenu={closeMobileMenu} badge={item.badge}>
                      {item.name}
                  </SidebarNavLink>
                ))}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>

      <div className="p-3 border-t border-border mt-auto">
        {!isMobile && (
          <Button variant="ghost" size="icon" onClick={toggleSidebar} className={cn("w-full justify-center mb-2", isCollapsed ? "mx-auto" : "ml-auto")}>
            {isOpen ? <ChevronsLeft className="h-5 w-5" /> : <ChevronsRight className="h-5 w-5" />}
          </Button>
        )}
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <button className={cn("w-full flex items-center gap-3 p-2 rounded-lg hover:bg-muted", isCollapsed && "justify-center")}>
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={`https://i.pravatar.cc/150?u=${user?.id}`} />
                    <AvatarFallback>{getInitials(user?.name)}</AvatarFallback>
                  </Avatar>
                  {!isCollapsed && (
                    <div className="text-left leading-tight">
                        <p className="font-semibold text-sm">{user?.name}</p>
                        <p className="text-xs text-muted-foreground">{user?.email}</p>
                    </div>
                  )}
                </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 mb-2" align="end">
                <DropdownMenuItem onClick={() => navigate(`/${user?.role === 'student' ? 'dashboard' : user?.role}/profile`)}>
                    <UserCircle className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate(`/${user?.role === 'student' ? 'dashboard' : user?.role}/appearance`)}>
                    <Palette className="mr-2 h-4 w-4" />
                    <span>Appearance</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </motion.div>
  );
};

export default Sidebar;
