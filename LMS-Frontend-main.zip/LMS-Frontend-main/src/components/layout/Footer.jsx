import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, MessageCircle } from 'lucide-react';

const Footer = () => {
  const handleWhatsAppClick = () => {
    window.open('https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20help%20choosing%20a%20course%20and%20booking%20a%20demo.', '_blank');
  };

  return (
    <footer className="bg-secondary/30 border-t border-border mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <img
                src="https://horizons-cdn.hostinger.com/7c77bb82-84e0-4421-92d7-3bd545a3adf8/be5fb749c9e12941c9958679d295b1b4.png"
                alt="Finchtalk Logo"
                className="h-10 md:h-12"
              />
            </Link>
            <p className="text-sm text-muted-foreground pt-4">
              Live Zoom classes, recordings, and hands-on cloud labs.
            </p>
          </div>

          <div>
            <span className="font-semibold text-foreground mb-4 block">Quick Links</span>
            <div className="space-y-2">
              <Link to="/courses" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                Courses
              </Link>
              <Link to="/workshops" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                Workshops
              </Link>
              <Link to="/membership" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                Membership
              </Link>
              <Link to="/about" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                About
              </Link>
            </div>
          </div>

          <div>
            <span className="font-semibold text-foreground mb-4 block">Legal</span>
            <div className="space-y-2">
              <Link to="/policies" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                Terms of Service
              </Link>
              <Link to="/privacy" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                Privacy Policy
              </Link>
              <Link to="/refunds" className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                Refunds & Cancellations
              </Link>
            </div>
          </div>

          <div>
            <span className="font-semibold text-foreground mb-4 block">Get in Touch</span>
            <div className="space-y-3">
              <button
                onClick={handleWhatsAppClick}
                className="flex items-center space-x-2 text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Support</span>
              </button>
              <Link to="/contact" className="flex items-center space-x-2 text-sm text-muted-foreground hover:text-primary transition-colors">
                <Mail className="w-4 h-4" />
                <span>Contact Us</span>
              </Link>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Finchtalk. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;