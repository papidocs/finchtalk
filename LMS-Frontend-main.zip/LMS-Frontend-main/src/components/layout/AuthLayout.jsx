
import React from 'react';
import { Link } from 'react-router-dom';
import FinchTalkLogo from '@/assets/finchtalk_logo.svg';

const AuthLayout = ({ children, title, description, footerText, footerLinkText, footerLinkTo }) => {
  return (
    <div className="relative min-h-screen w-full flex items-center justify-center p-4 overflow-hidden bg-background">
      {/* Background Glows */}
      <div className="absolute top-[-20%] left-[-20%] w-96 h-96 bg-primary/20 rounded-full filter blur-3xl opacity-30 animate-pulse"></div>
      <div className="absolute bottom-[-20%] right-[-20%] w-96 h-96 bg-accent/20 rounded-full filter blur-3xl opacity-30 animate-pulse animation-delay-4000"></div>

      <div className="relative w-full max-w-md">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-primary to-accent rounded-2xl blur-lg opacity-40 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt"></div>
        <div className="relative p-6 sm:p-8 bg-background/80 backdrop-blur-md rounded-2xl border border-border/50">
          <div className="text-center mb-8">
            <Link to="/" className="inline-block mx-auto mb-6">
              <img src={FinchTalkLogo} alt="Finchtalk Logo" className="h-16" />
            </Link>
            <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
            <p className="text-muted-foreground mt-2">{description}</p>
          </div>
          
          {children}

          <p className="mt-8 text-center text-sm text-muted-foreground">
            {footerText}{' '}
            <Link to={footerLinkTo} className="font-medium text-primary hover:underline">
              {footerLinkText}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;
