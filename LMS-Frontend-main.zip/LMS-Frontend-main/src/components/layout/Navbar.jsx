
import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, User, LogOut, LayoutDashboard, Briefcase, UserCircle, Shield, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import { ThemeSwitcher } from '@/components/ThemeSwitcher';
import MegaMenu from '@/components/nav/MegaMenu';
import { coursesMenuData, workshopsMenuData } from '@/lib/menuData';

const Navbar = () => {
  // Hooks must be called at the top level
  const [isOpen, setIsOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState(null);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isAuthenticated, logout, role } = useAuth();
  const navMenuRef = useRef(null);
  const timeoutRef = useRef(null);

  const isDashboard = location.pathname.startsWith('/dashboard') || location.pathname.startsWith('/instructor') || location.pathname.startsWith('/admin');

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
    setActiveMenu(null);
  }, [location]);
  
  // Conditional return after all hooks have been called
  if (isDashboard) {
    return null;
  }

  const handleMouseEnter = (menu) => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setActiveMenu(menu);
  };
  
  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => {
      setActiveMenu(null);
    }, 200);
  };

  const getInitials = (name = '') => name.split(' ').map(n => n[0]).join('');

  const UserNav = () => {
    if (!isAuthenticated) {
      return (
        <>
          <ThemeSwitcher />
          <Button variant="ghost" onClick={() => navigate('/login')}>Login</Button>
          <Button onClick={() => navigate('/register')}>Sign Up</Button>
        </>
      );
    }

    let dashboardPath = '/dashboard';
    let dashboardLabel = 'My Learning';
    let dashboardIcon = <LayoutDashboard className="mr-2 h-4 w-4" />;

    if (role === 'instructor') {
      dashboardPath = '/instructor';
      dashboardLabel = 'Instructor';
      dashboardIcon = <Briefcase className="mr-2 h-4 w-4" />;
    } else if (role === 'admin') {
      dashboardPath = '/admin';
      dashboardLabel = 'Admin Panel';
      dashboardIcon = <Shield className="mr-2 h-4 w-4" />;
    }

    return (
      <>
        <ThemeSwitcher />
        <Button variant="ghost" onClick={() => navigate(dashboardPath)}>{dashboardLabel}</Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-10 w-10 rounded-full">
              <Avatar className="h-10 w-10">
                 <AvatarImage src={`https://i.pravatar.cc/150?u=${user.id}`} alt={user.name} />
                <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none">{user.name}</p>
                <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate(dashboardPath)}>{dashboardIcon} {dashboardLabel}</DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate(`${dashboardPath}/profile`)}><UserCircle className="mr-2 h-4 w-4" /> Profile</DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate(`${dashboardPath}/appearance`)}><Palette className="mr-2 h-4 w-4" /> Appearance</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={logout}><LogOut className="mr-2 h-4 w-4" /> Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </>
    );
  };

  return (
    <nav className={cn("fixed top-0 left-0 right-0 z-50 transition-all duration-300", scrolled ? "bg-background/95 backdrop-blur-md border-b border-border shadow-lg" : "bg-transparent")}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20 md:h-24 relative">
          <Link to="/" className="flex items-center space-x-2 group">
            <img
              src="https://horizons-cdn.hostinger.com/7c77bb82-84e0-4421-92d7-3bd545a3adf8/be5fb749c9e12941c9958679d295b1b4.png"
              alt="Finchtalk Logo"
              className="h-10 md:h-12"
            />
          </Link>

          <div 
            ref={navMenuRef}
            onMouseLeave={handleMouseLeave}
            className="hidden lg:flex items-center justify-center absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
          >
            <div className="flex items-center space-x-1">
              <MegaMenu 
                  triggerLabel="Courses"
                  menuId="courses"
                  activeMenu={activeMenu}
                  onMouseEnter={() => handleMouseEnter('courses')}
                  categories={coursesMenuData}
                  searchPlaceholder="Search courses..."
                  allLink="/courses/browse"
              />
              <MegaMenu 
                  triggerLabel="Workshops"
                  menuId="workshops"
                  activeMenu={activeMenu}
                  onMouseEnter={() => handleMouseEnter('workshops')}
                  categories={workshopsMenuData}
                  searchPlaceholder="Search workshops..."
                  allLink="/workshops"
              />
              <Link to="/membership" className={cn("px-4 py-2 rounded-lg text-sm font-medium transition-all hover:bg-secondary/50", location.pathname === "/membership" ? "text-primary" : "text-foreground/80 hover:text-foreground")}>
                Membership
              </Link>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden lg:flex items-center gap-2">
              <UserNav />
            </div>

            <button onClick={() => setIsOpen(!isOpen)} className="lg:hidden p-2 rounded-lg hover:bg-secondary/50 transition-colors">
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="lg:hidden bg-background/98 backdrop-blur-md border-b border-border">
            <div className="container mx-auto px-4 py-4 space-y-1">
              <div className="flex justify-end pb-2">
                <ThemeSwitcher />
              </div>
              
              <MegaMenu 
                  triggerLabel="Courses"
                  categories={coursesMenuData}
                  searchPlaceholder="Search courses..."
                  allLink="/courses/browse"
                  onMobileLinkClick={() => setIsOpen(false)}
              />
              <MegaMenu 
                  triggerLabel="Workshops"
                  categories={workshopsMenuData}
                  searchPlaceholder="Search workshops..."
                  allLink="/workshops"
                  onMobileLinkClick={() => setIsOpen(false)}
              />
             <Link to="/membership" onClick={() => setIsOpen(false)} className={cn("block px-4 py-3 rounded-lg text-sm font-medium transition-all", location.pathname === "/membership" ? "bg-primary/10 text-primary" : "text-foreground/80 hover:bg-secondary/50 hover:text-foreground")}>
                Membership
              </Link>
              <div className="border-t border-border my-2" />
               {isAuthenticated ? (
                  <>
                    {role === 'student' && <Link to="/dashboard" onClick={() => setIsOpen(false)} className="block px-4 py-3 rounded-lg text-sm font-medium text-foreground/80 hover:bg-secondary/50">My Learning</Link>}
                    {role === 'instructor' && <Link to="/instructor" onClick={() => setIsOpen(false)} className="block px-4 py-3 rounded-lg text-sm font-medium text-foreground/80 hover:bg-secondary/50">Instructor</Link>}
                    {role === 'admin' && <Link to="/admin" onClick={() => setIsOpen(false)} className="block px-4 py-3 rounded-lg text-sm font-medium text-foreground/80 hover:bg-secondary/50">Admin Panel</Link>}
                    <Link to={`/${role === 'student' ? 'dashboard' : role}/profile`} onClick={() => setIsOpen(false)} className="block px-4 py-3 rounded-lg text-sm font-medium text-foreground/80 hover:bg-secondary/50">Profile</Link>
                    <button onClick={() => { logout(); setIsOpen(false); }} className="w-full text-left block px-4 py-3 rounded-lg text-sm font-medium text-red-500 hover:bg-red-500/10">Logout</button>
                  </>
               ) : (
                <>
                  <Link to="/login" onClick={() => setIsOpen(false)} className="block px-4 py-3 rounded-lg text-sm font-medium text-foreground/80 hover:bg-secondary/50">Login</Link>
                  <Button onClick={() => { navigate('/register'); setIsOpen(false); }} className="w-full mt-2">Sign Up</Button>
                </>
               )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
