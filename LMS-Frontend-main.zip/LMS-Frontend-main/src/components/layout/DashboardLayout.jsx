import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import useLocalStorage from 'react-use-localstorage';
import Sidebar from '@/components/layout/Sidebar';
import { cn } from '@/lib/utils';
import { Menu } from 'lucide-react';
import { Button } from '../ui/button';

const DashboardLayout = () => {
  const [isSidebarOpen, setSidebarOpen] = useLocalStorage('sidebar-open', 'true');
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(isSidebarOpen === 'true' ? 'false' : 'true');
  };

  const parsedSidebarOpen = isSidebarOpen === 'true';

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar isOpen={parsedSidebarOpen} toggleSidebar={toggleSidebar} />
      </div>

      {/* Mobile Sidebar (Drawer) */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden" onClick={() => setMobileMenuOpen(false)}>
          <div className="fixed inset-y-0 left-0 w-[86%] max-w-sm bg-background border-r border-border" onClick={e => e.stopPropagation()}>
            <Sidebar isOpen={true} toggleSidebar={() => {}} isMobile={true} closeMobileMenu={() => setMobileMenuOpen(false)} />
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className={cn(
        "flex-1 flex flex-col overflow-y-auto transition-all duration-300",
        parsedSidebarOpen ? "lg:ml-[248px]" : "lg:ml-[72px]"
      )}>
        {/* Mobile Header */}
        <header className="lg:hidden sticky top-0 bg-background/80 backdrop-blur-sm z-40 border-b border-border flex items-center h-16 px-4">
          <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(true)}>
            <Menu className="h-6 w-6" />
          </Button>
          <span className="text-lg font-semibold ml-4">Finchtalk</span>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;