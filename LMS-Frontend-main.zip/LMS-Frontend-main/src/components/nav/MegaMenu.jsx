// src/components/nav/MegaMenu.jsx
import React, { useMemo, useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Search } from "lucide-react";

/**
 * Props:
 * - triggerLabel: string
 * - menuId: string
 * - activeMenu: string | null
 * - onMouseEnter: () => void
 * - categories: Array<any>  // supports {title|label|name, items|links|children|courses}
 * - searchPlaceholder?: string
 * - allLink?: string
 * - onMobileLinkClick?: () => void
 */
export default function MegaMenu({
  triggerLabel,
  menuId,
  activeMenu,
  onMouseEnter,
  categories = [],
  searchPlaceholder = "Search…",
  allLink = "#",
  onMobileLinkClick,
}) {
  const isDesktopOpen = activeMenu === menuId;

  // Normalize incoming data to a consistent shape
  const normalized = useMemo(() => {
    const toLabel = (obj) =>
      obj?.title ?? obj?.label ?? obj?.name ?? "Category";
    const toItems = (obj) =>
      (obj?.items ??
        obj?.links ??
        obj?.children ??
        obj?.courses ??
        []
      ).map((x) => ({
        title: x?.title ?? x?.label ?? x?.name ?? "Untitled",
        href: x?.href ?? x?.to ?? x?.url ?? allLink,
        meta: x?.meta ?? x?.subtitle ?? x?.duration ?? x?.tagline,
      }));

    return (categories || []).map((c) => ({
      label: toLabel(c),
      items: toItems(c),
    }));
  }, [categories, allLink]);

  // Choose first category that has items (fallback to 0)
  const defaultIndex = useMemo(() => {
    const idx = normalized.findIndex((c) => c.items.length > 0);
    return idx >= 0 ? idx : 0;
  }, [normalized]);

  const [activeIdx, setActiveIdx] = useState(defaultIndex);

  useEffect(() => {
    if (isDesktopOpen) setActiveIdx(defaultIndex);
  }, [isDesktopOpen, defaultIndex]);

  // Mobile accordion toggle
  const [mobileOpen, setMobileOpen] = useState(false);

  const triggerCls =
    "px-4 py-2 rounded-lg text-sm font-medium transition-colors " +
    "text-foreground/80 hover:text-foreground hover:bg-secondary/50";

  return (
    <div className="relative" onMouseEnter={onMouseEnter}>
      {/* Trigger */}
      <button
        type="button"
        className={triggerCls}
        onClick={() => setMobileOpen((v) => !v)}
      >
        {triggerLabel}
      </button>

      {/* ===== Desktop panel (centered) ===== */}
      <div
        className={cn(
          "hidden lg:block",
          isDesktopOpen ? "pointer-events-auto" : "pointer-events-none"
        )}
      >
        <div
          className={cn(
            // Center on desktop
            "md:fixed md:top-[96px] md:left-1/2 md:-translate-x-1/2 md:right-auto",
            "z-50 mt-3",
            isDesktopOpen ? "opacity-100" : "opacity-0",
            "transition-opacity duration-150",
            // Box
            "w-[min(92vw,980px)] max-h-[80vh] overflow-hidden",
            "rounded-2xl border border-border bg-background/95 shadow-2xl backdrop-blur supports-[backdrop-filter]:bg-background/80"
          )}
        >
          <div className="grid grid-cols-12">
            {/* Left: categories list */}
            <aside className="col-span-4 bg-muted/30 p-4 md:p-6 border-r border-border">
              <p className="text-xs font-medium text-muted-foreground mb-3">
                CATEGORIES
              </p>
              <ul className="space-y-1">
                {normalized.map((c, idx) => (
                  <li key={`${c.label}-${idx}`}>
                    <button
                      onMouseEnter={() => setActiveIdx(idx)}
                      onFocus={() => setActiveIdx(idx)}
                      className={cn(
                        "w-full text-left px-3 py-2 rounded-lg transition",
                        idx === activeIdx
                          ? "bg-secondary/70 text-foreground"
                          : "hover:bg-secondary/50 text-foreground/80"
                      )}
                      aria-current={idx === activeIdx ? "true" : "false"}
                    >
                      {c.label}
                    </button>
                  </li>
                ))}
                {normalized.length === 0 && (
                  <li className="text-sm text-muted-foreground px-3 py-2">
                    No categories found.
                  </li>
                )}
              </ul>
            </aside>

            {/* Right: items of active category */}
            <section className="col-span-8 p-4 md:p-6">
              <div className="mb-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <input
                    type="text"
                    placeholder={searchPlaceholder}
                    className="w-full h-10 pl-9 pr-3 rounded-lg bg-background border border-border outline-none focus:ring-2 ring-primary/40"
                  />
                </div>
              </div>

              <div className="space-y-3">
                {(normalized[activeIdx]?.items ?? []).map((it, i) => (
                  <Link
                    key={`${it.title}-${i}`}
                    to={it.href}
                    className="block p-3 rounded-lg hover:bg-secondary/50"
                  >
                    <div className="text-sm font-medium">{it.title}</div>
                    {it.meta && (
                      <div className="text-xs text-muted-foreground">
                        {it.meta}
                      </div>
                    )}
                  </Link>
                ))}

                {(!normalized[activeIdx] ||
                  normalized[activeIdx].items.length === 0) && (
                  <div className="text-sm text-muted-foreground p-3">
                    Nothing to show here yet.
                  </div>
                )}
              </div>

              <div className="mt-5">
                <Link
                  to={allLink}
                  className="inline-flex items-center text-sm px-3 py-2 rounded-lg border border-border hover:bg-secondary/50"
                >
                  Browse all
                </Link>
              </div>
            </section>
          </div>
        </div>
      </div>

      {/* ===== Mobile accordion (inside small-screen drawer) ===== */}
      <div className="lg:hidden">
        {mobileOpen && (
          <div className="px-2 pb-2">
            <div className="mt-2">
              <div className="relative mb-3">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder={searchPlaceholder}
                  className="w-full h-10 pl-9 pr-3 rounded-lg bg-background border border-border outline-none focus:ring-2 ring-primary/40"
                />
              </div>

              {normalized.map((c, idx) => (
                <div key={`${c.label}-${idx}`} className="mb-2">
                  <div className="text-xs font-medium text-muted-foreground px-1 mb-1">
                    {c.label}
                  </div>
                  <ul className="space-y-1">
                    {c.items.map((it, i) => (
                      <li key={`${it.title}-${i}`}>
                        <Link
                          to={it.href}
                          onClick={onMobileLinkClick}
                          className="block px-3 py-2 rounded-lg hover:bg-secondary/50"
                        >
                          {it.title}
                        </Link>
                      </li>
                    ))}
                    {c.items.length === 0 && (
                      <li className="text-sm text-muted-foreground px-3 py-2">
                        Nothing here yet.
                      </li>
                    )}
                  </ul>
                </div>
              ))}

              <Link
                to={allLink}
                onClick={onMobileLinkClick}
                className="inline-flex items-center text-sm mt-2 px-3 py-2 rounded-lg border border-border hover:bg-secondary/50"
              >
                Browse all
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
