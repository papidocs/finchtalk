import React, { createContext, useState, useEffect, useContext } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { mockLogin, mockRegister, getMockUserById, initializeMockData } from '@/lib/mockApi';

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    initializeMockData();
    try {
      const storedUserId = localStorage.getItem('finchtalk_user_id');
      if (storedUserId) {
        const storedUser = getMockUserById(storedUserId);
        if (storedUser) setUser(storedUser);
        else localStorage.removeItem('finchtalk_user_id');
      }
    } catch {
      localStorage.removeItem('finchtalk_user_id');
    } finally {
      setLoading(false);
    }
  }, []);

  const safeNext = () => {
    // Support both ?next=/path and router state.from
    const qs = new URLSearchParams(location.search);
    const nextFromQuery = qs.get('next');
    const nextFromState = location?.state?.from?.pathname;

    const candidate = nextFromQuery || nextFromState || '';
    // Only allow internal paths and avoid /login loops
    if (candidate && candidate.startsWith('/') && !candidate.startsWith('/login')) {
      return candidate;
    }
    return null;
  };

  const login = async (email, password, intendedRole = null) => {
    const loggedInUser = mockLogin(email, password); // throws on failure

    if (intendedRole && loggedInUser.role !== intendedRole) {
      setUser(null);
      localStorage.removeItem('finchtalk_user_id');
      if (intendedRole === 'instructor') {
        throw new Error('Not an instructor account. Please use the main login.');
      }
      throw new Error(`This login is for ${intendedRole}s only.`);
    }

    setUser(loggedInUser);
    localStorage.setItem('finchtalk_user_id', loggedInUser.id);

    // Destination priority: ?next / state.from → role default
    const next = safeNext();
    let destination =
      loggedInUser.role === 'admin'
        ? '/admin'
        : loggedInUser.role === 'instructor'
        ? '/instructor'
        : '/dashboard';

    navigate(next || destination, { replace: true });
    return loggedInUser;
  };

  const register = (name, email, password) => {
    const newUser = mockRegister(name, email, password); // throws on failure
    setUser(newUser);
    localStorage.setItem('finchtalk_user_id', newUser.id);
    navigate('/dashboard', { replace: true });
    return newUser;
  };

  const logout = () => {
    const previousUserRole = user?.role;
    setUser(null);
    localStorage.removeItem('finchtalk_user_id');

    // Keep your existing behavior: instructors → /instructor/login; others → /login
    if (previousUserRole === 'instructor') navigate('/instructor/login');
    else navigate('/login');
  };

  const value = {
    user,
    isAuthenticated: !!user,
    role: user?.role || 'guest',
    loading,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{!loading && children}</AuthContext.Provider>;
};
