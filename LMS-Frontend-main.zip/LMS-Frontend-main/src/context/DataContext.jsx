import React, { createContext, useContext, useState } from 'react';
import { 
  getMockCourses, 
  getMockWorkshops,
  getMockTicketsForUser,
  createMockTicket,
  updateMockTicket,
  getMockDriveItems,
  createMockDriveItem,
  addMockReplyToTicket,
  getMockFriends, 
  getMockFriendRequests, 
  getMockFriendSuggestions,
  getMockLeaderboard,
  getRegisteredWorkshopsForUser,
  getMockQuizzes,
  getMockCertificates,
  getMockWishlist,
  getMockOrders,
  getMockServiceRequests,
  createMockServiceRequest,
} from '@/lib/mockApi';

const DataContext = createContext();

export const useData = () => {
  return useContext(DataContext);
};

export const DataProvider = ({ children }) => {
  // This would be replaced with API calls in a real app
  const getCourses = () => getMockCourses();
  const getWorkshops = () => getMockWorkshops();
  const getTicketsForUser = (userId) => getMockTicketsForUser(userId);
  const createTicket = (userId, subject, message) => createMockTicket(userId, subject, message);
  const updateTicket = (ticketId, updates) => updateMockTicket(ticketId, updates);
  const addReplyToTicket = (ticketId, text, from) => addMockReplyToTicket(ticketId, text, from);
  const getDriveItems = () => getMockDriveItems();
  const createDriveItem = (item) => createMockDriveItem(item);
  const getFriends = () => getMockFriends();
  const getFriendRequests = () => getMockFriendRequests();
  const getFriendSuggestions = () => getMockFriendSuggestions();
  const getLeaderboard = (filters) => getMockLeaderboard(filters);
  const getRegisteredWorkshops = (userId) => getRegisteredWorkshopsForUser(userId);
  const getQuizzes = () => getMockQuizzes();
  const getCertificates = (userId) => getMockCertificates(userId);
  const getWishlist = (userId) => getMockWishlist(userId);
  const getOrders = (userId) => getMockOrders(userId);
  const getServiceRequests = (userId) => getMockServiceRequests(userId);
  const createServiceRequest = (userId, type, details) => createMockServiceRequest(userId, type, details);


  const value = {
    getCourses,
    getWorkshops,
    getTicketsForUser,
    createTicket,
    updateTicket,
    addReplyToTicket,
    getDriveItems,
    createDriveItem,
    getFriends,
    getFriendRequests,
    getFriendSuggestions,
    getLeaderboard,
    getRegisteredWorkshops,
    getQuizzes,
    getCertificates,
    getWishlist,
    getOrders,
    getServiceRequests,
    createServiceRequest,
  };

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
};