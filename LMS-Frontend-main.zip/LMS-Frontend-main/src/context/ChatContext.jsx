import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { processChatMessage } from '@/lib/chatLogic';

const ChatContext = createContext();

export const useChat = () => useContext(ChatContext);

export const ChatProvider = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [chatState, setChatState] = useState({ stage: 'greeting', history: [] });
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    // Initial greeting when chat opens for the first time
    if (isOpen && messages.length === 0) {
      const initialResponse = processChatMessage(null, chatState, isAuthenticated, user);
      setMessages([initialResponse.message]);
      setChatState(initialResponse.nextState);
    }
  }, [isOpen]);

  const toggleChat = () => setIsOpen(!isOpen);

  const sendMessage = (userInput) => {
    // Add user message
    const userMessage = { id: Date.now(), sender: 'user', text: userInput.text, buttons: [] };
    setMessages(prev => [...prev, userMessage]);

    // Get bot response
    setTimeout(() => {
      const { message: botMessage, nextState } = processChatMessage(userInput, chatState, isAuthenticated, user);
      setMessages(prev => [...prev, botMessage]);
      setChatState(nextState);
    }, 500);
  };

  const value = {
    isOpen,
    toggleChat,
    messages,
    sendMessage,
    chatState
  };

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
};