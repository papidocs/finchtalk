import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { CheckCircle, Info, Star, Zap } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const Membership = () => {
  const { toast } = useToast();

  const plans = [
    {
      name: 'Starter',
      price: '₹5,000',
      cycle: '/cycle',
      features: [
        '3 Courses/cycle',
        '10 Workshops/cycle',
        'Full Recordings Library',
        'Standard Support'
      ],
      cta: 'Choose Starter'
    },
    {
      name: 'Plus',
      price: '₹10,000',
      cycle: '/cycle',
      isPopular: true,
      features: [
        'Unlimited Courses',
        '20 Workshops/cycle',
        'Full Recordings Library',
        'Priority Support'
      ],
      cta: 'Choose Plus'
    },
    {
      name: 'Pro',
      price: '₹20,000',
      cycle: '/cycle',
      features: [
        'All Plus features',
        'SME 1:1 Support (10 tickets/cycle)',
        'Early access to new content',
        'Dedicated Account Manager'
      ],
      cta: 'Choose Pro'
    }
  ];

  const handleChoosePlan = (planName) => {
    toast({
      title: `Welcome to the ${planName} Plan!`,
      description: "You're one step closer to unlocking your potential.",
    });
  };

  return (
    <>
      <Helmet>
        <title>Membership Plans that Unlock Learning | Finchtalk</title>
        <meta name="description" content="Choose from our Starter, Plus, and Pro membership plans to get access to courses, workshops, recordings, and expert support." />
      </Helmet>

      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-semibold mb-4">
              Memberships that Unlock Learning
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Flexible plans designed to fit your learning goals and budget. Quotas reset monthly.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-card border rounded-xl p-8 flex flex-col ${plan.isPopular ? 'border-primary shadow-2xl' : 'border-border'}`}
              >
                {plan.isPopular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-primary text-white text-sm font-semibold rounded-full flex items-center gap-1">
                    <Star className="w-4 h-4" /> Most Popular
                  </div>
                )}
                <div className="flex-1">
                  <h3 className="text-2xl font-semibold mb-2">{plan.name}</h3>
                  <div className="mb-6">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-muted-foreground">{plan.cycle}</span>
                  </div>
                  <ul className="space-y-4">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-center">
                        <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                        <span className="text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <Button onClick={() => handleChoosePlan(plan.name)} size="lg" className={`w-full mt-8 ${plan.isPopular ? 'bg-primary hover:bg-primary/90' : 'bg-secondary hover:bg-secondary/80'}`}>
                  {plan.cta}
                </Button>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-12 bg-secondary/30 border border-border rounded-xl p-6 text-center"
          >
            <div className="flex items-center justify-center gap-3">
              <Info className="w-5 h-5 text-muted-foreground" />
              <p className="text-muted-foreground text-sm">
                Notes: Quotas reset monthly • Fair-use policy applies • 2-login limit per account.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default Membership;