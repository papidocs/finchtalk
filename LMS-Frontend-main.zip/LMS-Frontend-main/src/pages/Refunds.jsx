import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const Refunds = () => {
  return (
    <>
      <Helmet>
        <title>Refunds & Cancellations Policy | Finchtalk</title>
        <meta name="description" content="Read the Refunds & Cancellations policy for Finchtalk courses, workshops, and memberships." />
      </Helmet>
      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="prose prose-invert lg:prose-xl mx-auto"
          >
            <h1>Refunds & Cancellations</h1>
            <p className="lead">Last updated: November 2, 2025</p>
            <p>Thank you for choosing Finchtalk. We want to ensure you are satisfied with your learning experience.</p>
            
            <h2>Courses and Workshops</h2>
            <p>A full refund will be issued if you cancel your registration at least 7 days before the course or workshop start date. Cancellations made within 7 days of the start date are not eligible for a refund, but you may transfer your registration to a future session.</p>

            <h2>Memberships</h2>
            <p>Membership fees are non-refundable. You may cancel your membership at any time to prevent future billing. You will retain access to your membership benefits until the end of the current billing cycle.</p>
            
            <h2>Contact Us</h2>
            <p>If you have any questions about our Refunds and Cancellations Policy, please contact us at support@finchtalk.com.</p>
            
            <p><em>(This is a placeholder. A complete Refunds & Cancellations Policy is required for a live website.)</em></p>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default Refunds;