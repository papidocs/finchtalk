import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { FlaskConical, Calendar, Users, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Workshops = () => {
  const { toast } = useToast();

  const workshops = [
    {
      id: 1,
      title: 'Terraform Infrastructure as Code',
      date: 'Dec 15, 2025',
      seats: '12 seats left',
      duration: '3 hours',
      description: 'Learn to manage your infrastructure with code using Terraform. A hands-on workshop for cloud engineers.',
      slug: 'terraform-iac'
    },
    {
      id: 2,
      title: 'Python for Data Analysis',
      date: 'Dec 22, 2025',
      seats: '8 seats left',
      duration: '4 hours',
      description: 'Dive into data analysis with Python, using libraries like Pandas and Matplotlib to process and visualize data.',
      slug: 'python-data-analysis'
    },
    {
      id: 3,
      title: 'CI/CD with GitHub Actions',
      date: 'Jan 5, 2026',
      seats: '15 seats left',
      duration: '3 hours',
      description: 'Automate your software development workflows from code to production using GitHub Actions.',
      slug: 'github-actions-cicd'
    },
    {
      id: 4,
      title: 'Introduction to Docker',
      date: 'Jan 12, 2026',
      seats: '10 seats left',
      duration: '3 hours',
      description: 'Get started with containerization and learn how to build, run, and share applications with Docker.',
      slug: 'intro-to-docker'
    }
  ];

  const handleWaitlist = (title) => {
    toast({
      title: `Joined Waitlist for ${title}`,
      description: "We'll notify you when a spot opens up!",
    });
  };

  const handleRequestDemo = () => {
    window.open('https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20to%20know%20more%20about%20your%20workshops.', '_blank');
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1
    }
  };

  return (
    <>
      <Helmet>
        <title>Hands-On Workshops (Labs Included) | Finchtalk</title>
        <meta name="description" content="Join our limited-seat, hands-on workshops. Includes labs, live instruction, and practical skills development." />
      </Helmet>

      <div className="pt-28 md:pt-32 pb-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12 md:mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-semibold mb-4">
              Workshops <span className="text-accent">(Labs Included)</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Intensive, hands-on sessions designed to give you practical skills in just a few hours. Seats are limited to ensure personalized attention.
            </p>
          </motion.div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {workshops.map((workshop) => (
              <motion.div
                key={workshop.id}
                variants={itemVariants}
                className="bg-card border border-border rounded-xl overflow-hidden flex flex-col group transition-all duration-300 hover:shadow-xl hover:border-primary/50"
              >
                <div className="p-6 flex flex-col flex-grow">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-semibold text-card-foreground group-hover:text-primary transition-colors">{workshop.title}</h3>
                    <div className="p-3 bg-accent/10 text-accent rounded-lg flex-shrink-0">
                      <FlaskConical className="w-5 h-5" />
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-6 flex-grow">{workshop.description}</p>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4 mr-3 text-primary" />
                      <span>{workshop.date} ({workshop.duration})</span>
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Users className="w-4 h-4 mr-3 text-primary" />
                      <span>{workshop.seats}</span>
                    </div>
                  </div>
                </div>
                <div className="bg-muted/30 px-6 py-4 border-t border-border">
                    <Link to={`/workshop/${workshop.slug}`} className="w-full">
                         <Button variant="ghost" className="w-full justify-between items-center text-primary">
                            <span>View Details</span>
                            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </Button>
                    </Link>
                </div>
              </motion.div>
            ))}
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: workshops.length * 0.1 + 0.2 }}
            className="text-center mt-16"
          >
             <h3 className="text-xl font-semibold mb-4">Can't find a workshop?</h3>
             <p className="text-muted-foreground mb-6">Let us know what you'd like to learn, or request a private demo.</p>
             <div className="flex justify-center gap-4">
                <Button onClick={handleRequestDemo}>Request a Demo</Button>
                <Button variant="outline">Suggest a Topic</Button>
             </div>
          </motion.div>

        </div>
      </div>
    </>
  );
};

export default Workshops;