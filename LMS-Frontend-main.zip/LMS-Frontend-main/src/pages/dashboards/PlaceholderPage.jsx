import React from 'react';
import { Helmet } from 'react-helmet';
import { Zap } from 'lucide-react';

const PlaceholderPage = ({ title }) => {
  return (
    <>
      <Helmet>
        <title>{title} | Finchtalk</title>
      </Helmet>
      <div className="flex flex-col items-center justify-center h-full text-center p-8 bg-card border border-border rounded-lg">
        <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mb-6">
          <Zap className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-3xl font-bold mb-2">{title}</h1>
        <p className="text-muted-foreground max-w-md">
          This feature is coming soon! We're hard at work building an amazing experience for you here.
        </p>
      </div>
    </>
  );
};

export default PlaceholderPage;