import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/context/AuthContext';
import { motion } from 'framer-motion';
import { Ticket, Clock, Users, BookOpen, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

const StatCard = ({ title, value, icon: Icon, change }) => (
    <div className="bg-card border border-border rounded-lg p-5">
        <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <Icon className="h-5 w-5 text-muted-foreground" />
        </div>
        <p className="text-3xl font-bold">{value}</p>
        <p className="text-xs text-muted-foreground">{change}</p>
    </div>
);

const InstructorDashboard = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const { toast } = useToast();

    const handleCreateCourse = () => {
        toast({ title: "Coming soon!", description: "The course creator is in development." });
        navigate('/instructor/courses');
    };

    return (
        <>
            <Helmet>
                <title>Instructor Overview | Finchtalk</title>
            </Helmet>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
                <div>
                    <h1 className="text-3xl font-bold">My Teaching Overview</h1>
                    <p className="text-muted-foreground">Welcome back, {user.name.split(' ')[0]}.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <StatCard title="Open Tickets" value="4" icon={Ticket} change="+1 from yesterday" />
                    <StatCard title="Avg. Response" value="18h" icon={Clock} change="-2h from last week" />
                    <StatCard title="Active Learners (7d)" value="1,204" icon={Users} change="+5% this week" />
                    <StatCard title="Upcoming Sessions" value="3" icon={Clock} change="1 today" />
                </div>
                
                <div className="bg-card border border-border rounded-lg p-8 text-center">
                    <h2 className="text-2xl font-semibold mb-2">Ready to Inspire?</h2>
                    <p className="text-muted-foreground mb-6">Create a new course or check on your student tickets.</p>
                    <div className="flex justify-center gap-4">
                        <Button onClick={handleCreateCourse}>
                            <BookOpen className="mr-2 h-4 w-4" /> Create a Course
                        </Button>
                        <Button variant="secondary" onClick={() => navigate('/instructor/tickets')}>
                            <MessageSquare className="mr-2 h-4 w-4" /> View Ticket Queue
                        </Button>
                    </div>
                </div>

            </motion.div>
        </>
    )
}

export default InstructorDashboard;