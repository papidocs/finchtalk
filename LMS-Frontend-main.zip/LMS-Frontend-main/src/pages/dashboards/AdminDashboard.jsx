import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/context/AuthContext';
import { motion } from 'framer-motion';
import {
  DollarSign, Users, BookOpen, ShoppingCart, Plus, Settings, Calendar, Ticket,
  ShieldCheck, BarChart3, FolderCog, UserPlus
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link, useNavigate } from 'react-router-dom';

const Stat = ({ title, value, icon: Icon, change }) => (
  <Card className="border-border">
    <CardContent className="p-5">
      <div className="flex items-center justify-between mb-2">
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <Icon className="h-5 w-5 text-muted-foreground" />
      </div>
      <p className="text-3xl font-bold">{value}</p>
      <p className="text-xs text-muted-foreground">{change}</p>
    </CardContent>
  </Card>
);

const QuickLink = ({ to, icon: Icon, label, desc }) => (
  <Link to={to} className="group">
    <Card className="h-full transition-colors hover:bg-secondary/40">
      <CardHeader className="space-y-1">
        <div className="flex items-center gap-2">
          <Icon className="h-5 w-5 text-muted-foreground group-hover:text-foreground" />
          <CardTitle className="text-base">{label}</CardTitle>
        </div>
        <CardDescription>{desc}</CardDescription>
      </CardHeader>
    </Card>
  </Link>
);

const AdminDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const firstName = (user?.name || 'Admin').split(' ')[0];

  // Demo "recent activity" — lightweight and local (no new deps)
  const recent = [
    { id: 'act1', icon: <UserPlus className="h-4 w-4" />, text: 'New instructor application: Jane Doe', when: '2h ago' },
    { id: 'act2', icon: <ShoppingCart className="h-4 w-4" />, text: 'Order ORD-1029 completed ($799)', when: '4h ago' },
    { id: 'act3', icon: <Ticket className="h-4 w-4" />, text: 'Ticket #T-785 escalated to L2', when: '5h ago' },
    { id: 'act4', icon: <BookOpen className="h-4 w-4" />, text: 'New course draft created: "GenAI for Devs"', when: '1d ago' },
  ];

  return (
    <>
      <Helmet>
        <title>Admin Dashboard | Finchtalk</title>
      </Helmet>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Welcome, {firstName}. Manage the platform from here.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => navigate('/admin/settings')}>
              <Settings className="h-4 w-4 mr-2" /> Settings
            </Button>
            <Button onClick={() => navigate('/admin/courses')}>
              <Plus className="h-4 w-4 mr-2" /> New Course
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Stat title="Total Revenue (30d)" value="$12,450" icon={DollarSign} change="+15.2% from last month" />
          <Stat title="New Users (30d)" value="243" icon={Users} change="-5% from last month" />
          <Stat title="Active Courses" value="28" icon={BookOpen} change="+2 this month" />
          <Stat title="Pending Orders" value="12" icon={ShoppingCart} change="3 new today" />
        </div>

        {/* Quick actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          <QuickLink to="/admin/courses" icon={FolderCog} label="Manage Courses" desc="Create, edit and publish" />
          <QuickLink to="/admin/workshops" icon={Calendar} label="Manage Workshops" desc="Schedule & capacity" />
          <QuickLink to="/admin/users" icon={Users} label="Users" desc="Learners & instructors" />
          <QuickLink to="/admin/orders" icon={ShoppingCart} label="Orders" desc="Payments & refunds" />
        </div>

        {/* System health + recent activity */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1">
            <CardHeader>
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-muted-foreground" />
                <CardTitle>System Health</CardTitle>
              </div>
              <CardDescription>Key backend services</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span>Auth Service</span>
                <span className="text-xs rounded-full px-2 py-1 bg-emerald-500/10 text-emerald-600">Operational</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Payments</span>
                <span className="text-xs rounded-full px-2 py-1 bg-amber-500/10 text-amber-600">Degraded</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Notifications</span>
                <span className="text-xs rounded-full px-2 py-1 bg-emerald-500/10 text-emerald-600">Operational</span>
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-muted-foreground" />
                <CardTitle>Recent Activity</CardTitle>
              </div>
              <CardDescription>Latest events across the platform</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {recent.map((r) => (
                <div key={r.id} className="flex items-center justify-between border-b last:border-none py-2">
                  <div className="flex items-center gap-2">
                    {r.icon}
                    <span>{r.text}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">{r.when}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* CTA block */}
        <Card>
          <CardHeader>
            <CardTitle>Need to triage tickets quickly?</CardTitle>
            <CardDescription>Jump straight into the global queue.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="secondary" asChild>
              <Link to="/admin/tickets"><Ticket className="h-4 w-4 mr-2" /> Go to Tickets</Link>
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    </>
  );
};

export default AdminDashboard;
