import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/context/AuthContext';
import { motion } from 'framer-motion';
import { getMockCourses, getMockSessions, getMockEnrollments } from '@/lib/mockApi';
import { Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const StudentDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Mock data fetching for widgets
  const allCourses = getMockCourses();
  const allEnrollments = getMockEnrollments();
  const myEnrollments = allEnrollments.filter(e => e.userId === user.id);
  const myCourseIds = myEnrollments.map(e => e.courseId);
  const myCourses = allCourses.filter(c => myCourseIds.includes(c.id));

  const allSessions = getMockSessions();
  const today = new Date('2025-11-02T00:00:00');
  const upcomingSessions = allSessions.filter(s => 
    new Date(s.date) >= today && myCourseIds.includes(s.courseId)
  ).slice(0, 3);
  
  const openInNewTab = (url) => window.open(url, '_blank', 'noopener,noreferrer');

  return (
    <>
      <Helmet>
        <title>My Learning | Finchtalk</title>
      </Helmet>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">My Learning Overview</h1>
            <p className="text-muted-foreground">Welcome back, {user.name.split(' ')[0]}!</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Continue Learning */}
          <div className="lg:col-span-2 bg-card border border-border rounded-lg p-6">
            <h2 className="font-semibold mb-4">Continue Learning</h2>
            {myCourses.length > 0 ? (
              <div className="space-y-4">
                {myCourses.slice(0, 2).map(course => (
                  <div key={course.id} className="bg-muted/50 p-4 rounded-md flex justify-between items-center">
                    <div>
                      <h3 className="font-semibold">{course.title}</h3>
                      <p className="text-sm text-muted-foreground">75% complete</p>
                    </div>
                    <Button onClick={() => navigate(`/dashboard/courses`)}>Resume</Button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-8">You are not enrolled in any courses yet.</p>
            )}
          </div>
          
          {/* Upcoming Sessions */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="font-semibold mb-4">Upcoming Sessions</h2>
            <div className="space-y-3">
              {upcomingSessions.map(session => (
                <div key={session.id} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-sm">{session.title}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Clock className="w-3 h-3" />{new Date(session.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                  <Button size="sm" onClick={() => openInNewTab(session.zoomJoinUrl)}>Join</Button>
                </div>
              ))}
               {upcomingSessions.length === 0 && <p className="text-muted-foreground text-sm text-center py-4">No sessions scheduled for your courses.</p>}
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
};

export default StudentDashboard;