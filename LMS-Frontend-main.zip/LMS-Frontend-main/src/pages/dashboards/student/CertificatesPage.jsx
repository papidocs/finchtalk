import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Award, Download, Share2, Search } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import finchtalkLogo from '@/assets/finchtalk_logo.svg';

const PlatformIcon = ({ icon, className }) => {
  const icons = {
    aws: () => <img alt="AWS logo" src="https://images.unsplash.com/photo-1658204212985-e0126040f88f" />,
    azure: () => <img alt="Azure logo" src="https://images.unsplash.com/photo-1658204212985-e0126040f88f" />,
    gcp: () => <img alt="GCP logo" src="https://images.unsplash.com/photo-1649180549324-3e03951391aa" />,
    // Add other icons as needed
  };

  const IconComponent = icons[icon] || 'div';
  return <IconComponent className={className} />;
};


const CertificateCard = ({ certificate, index }) => {
    const { toast } = useToast();

    const handleAction = (action) => {
        toast({
            title: `${action} Certificate`,
            description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        });
    };
    
    const cardVariants = {
        hidden: { opacity: 0, scale: 0.9 },
        visible: {
            opacity: 1,
            scale: 1,
            transition: {
                delay: index * 0.1,
                type: 'spring',
                stiffness: 260,
                damping: 20
            },
        },
    };

    return (
        <motion.div variants={cardVariants}>
        <Card className="overflow-hidden group hover:shadow-primary/20 hover:shadow-lg transition-all duration-300">
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-6 relative h-48 flex flex-col justify-between">
                 <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%232c3e50%22%20fill-opacity%3D%220.1%22%3E%3Cpath%20d%3D%22M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-30"></div>
                <div className="relative z-10 flex justify-between items-start">
                    <div>
                        <p className="text-sm font-bold text-primary">Certificate of Completion</p>
                        <p className="text-xs text-muted-foreground">Issued by Finchtalk</p>
                    </div>
                     <img src={finchtalkLogo} alt="Finchtalk Logo" className="w-8 h-8"/>
                </div>
                <div className="relative z-10">
                     <h2 className="text-2xl font-bold text-white truncate">{certificate.courseTitle}</h2>
                </div>
            </div>
            <CardContent className="p-6">
                <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">Issued on: {new Date(certificate.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                    <p className="text-sm text-muted-foreground">Certificate ID: <span className="font-mono text-foreground">{certificate.certificateId}</span></p>
                </div>
                 <div className="mt-6 flex gap-3">
                    <Button onClick={() => handleAction('Download')} className="flex-1">
                        <Download className="mr-2 h-4 w-4" /> Download
                    </Button>
                    <Button onClick={() => handleAction('Share')} variant="outline" className="flex-1">
                        <Share2 className="mr-2 h-4 w-4" /> Share
                    </Button>
                </div>
            </CardContent>
        </Card>
        </motion.div>
    );
};

const CertificatesPage = () => {
    const { user } = useAuth();
    const { getCertificates } = useData();
    const certificates = getCertificates(user.id);
    
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
            },
        },
    };

    return (
        <>
            <Helmet>
                <title>My Certificates | Finchtalk</title>
                <meta name="description" content="View and share your earned certificates." />
            </Helmet>
            <div className="space-y-8">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                >
                    <div>
                        <h1 className="text-3xl md:text-4xl font-bold tracking-tight flex items-center gap-3">
                            <Award className="w-8 h-8 text-primary" />
                            My Certificates
                        </h1>
                        <p className="text-muted-foreground mt-2">Your hard work, officially recognized. Share your achievements!</p>
                    </div>
                     <div className="relative w-full md:w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input placeholder="Search certificates..." className="pl-10" />
                    </div>
                </motion.div>

                {certificates.length > 0 ? (
                    <motion.div
                        variants={containerVariants}
                        initial="hidden"
                        animate="visible"
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                    >
                        {certificates.map((cert, i) => (
                            <CertificateCard key={cert.id} certificate={cert} index={i} />
                        ))}
                    </motion.div>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="text-center py-20 bg-card rounded-lg border border-dashed"
                    >
                        <Award className="mx-auto h-12 w-12 text-muted-foreground" />
                        <h3 className="mt-4 text-lg font-semibold">No Certificates Yet</h3>
                        <p className="mt-1 text-sm text-muted-foreground">Complete a course to earn your first certificate and see it here!</p>
                        <Button asChild className="mt-6">
                           <a href="/courses/browse">Browse Courses</a>
                        </Button>
                    </motion.div>
                )}
            </div>
        </>
    );
};

export default CertificatesPage;