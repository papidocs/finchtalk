import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { HelpCircle, PlusCircle, Send } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';

const ServiceRequestsPage = () => {
    const { user } = useAuth();
    const { getServiceRequests, createServiceRequest } = useData();
    const [requests, setRequests] = useState(() => getServiceRequests(user.id));
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [requestType, setRequestType] = useState('');
    const [requestDetails, setRequestDetails] = useState('');
    const { toast } = useToast();

    const handleSubmit = () => {
        if (!requestType || !requestDetails) {
            toast({
                title: 'Missing Information',
                description: 'Please select a request type and provide details.',
                variant: 'destructive',
            });
            return;
        }
        createServiceRequest(user.id, requestType, requestDetails);
        setRequests(getServiceRequests(user.id)); // Refresh the list
        toast({
            title: 'Request Submitted!',
            description: 'Your service request has been sent. We will get back to you soon.',
        });
        setIsDialogOpen(false);
        setRequestType('');
        setRequestDetails('');
    };
    
    const getStatusBadgeVariant = (status) => {
        switch (status) {
            case 'Completed': return 'success';
            case 'Pending': return 'warning';
            case 'In Progress': return 'info';
            case 'Cancelled': return 'destructive';
            default: return 'secondary';
        }
    };

    return (
        <>
            <Helmet>
                <title>Service Requests | Finchtalk</title>
                <meta name="description" content="Request special services like mentorship or resume reviews." />
            </Helmet>
            <div className="space-y-8">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                >
                    <div>
                        <h1 className="text-3xl md:text-4xl font-bold tracking-tight flex items-center gap-3">
                            <HelpCircle className="w-8 h-8 text-primary" />
                            Service Requests
                        </h1>
                        <p className="text-muted-foreground mt-2">Need personalized help? Request a special service here.</p>
                    </div>
                    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                        <DialogTrigger asChild>
                            <Button>
                                <PlusCircle className="mr-2 h-4 w-4" /> New Request
                            </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[425px]">
                            <DialogHeader>
                                <DialogTitle>Create a New Service Request</DialogTitle>
                                <DialogDescription>
                                    Select a service and provide details. Our team will review your request.
                                </DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-4 py-4">
                                <div className="grid grid-cols-4 items-center gap-4">
                                    <Label htmlFor="request-type" className="text-right">
                                        Service
                                    </Label>
                                    <Select onValueChange={setRequestType} value={requestType}>
                                        <SelectTrigger id="request-type" className="col-span-3">
                                            <SelectValue placeholder="Select a service" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="1-on-1 Mentorship">1-on-1 Mentorship</SelectItem>
                                            <SelectItem value="Resume Review">Resume Review</SelectItem>
                                            <SelectItem value="Project Consultation">Project Consultation</SelectItem>
                                            <SelectItem value="Career Advice">Career Advice</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                    <Label htmlFor="details" className="text-right">
                                        Details
                                    </Label>
                                    <Textarea
                                        id="details"
                                        className="col-span-3"
                                        placeholder="Please provide as much detail as possible..."
                                        value={requestDetails}
                                        onChange={(e) => setRequestDetails(e.target.value)}
                                    />
                                </div>
                            </div>
                            <DialogFooter>
                                <Button onClick={handleSubmit}>
                                    <Send className="mr-2 h-4 w-4" /> Submit Request
                                </Button>
                            </DialogFooter>
                        </DialogContent>
                    </Dialog>
                </motion.div>

                <Card>
                    <CardContent className="p-6 space-y-4">
                        {requests.length > 0 ? requests.map(req => (
                            <div key={req.id} className="flex flex-col md:flex-row justify-between md:items-center p-4 rounded-lg bg-muted/50 border">
                                <div>
                                    <p className="font-bold text-lg">{req.type}</p>
                                    <p className="text-sm text-muted-foreground mt-1">{req.details}</p>
                                    <p className="text-xs text-muted-foreground mt-2">
                                        Requested on: {new Date(req.created).toLocaleDateString()}
                                    </p>
                                </div>
                                <div className="mt-4 md:mt-0">
                                    <Badge variant={getStatusBadgeVariant(req.status)}>{req.status}</Badge>
                                </div>
                            </div>
                        )) : (
                            <div className="text-center py-12">
                                <p className="text-muted-foreground">You haven't made any service requests yet.</p>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        </>
    );
};

export default ServiceRequestsPage;