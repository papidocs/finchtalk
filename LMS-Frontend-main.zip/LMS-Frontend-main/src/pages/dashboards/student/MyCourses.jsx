import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/context/AuthContext';
import { getMockCourses, getMockEnrollments } from '@/lib/mockApi';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const MyCourses = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const allCourses = getMockCourses();
  const allEnrollments = getMockEnrollments();
  const myEnrollmentIds = allEnrollments.filter(e => e.userId === user.id).map(e => e.courseId);
  const myCourses = allCourses.filter(c => myEnrollmentIds.includes(c.id));

  return (
    <>
      <Helmet>
        <title>My Courses | Finchtalk</title>
      </Helmet>
      <div>
        <h1 className="text-3xl font-bold mb-6">My Courses</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {myCourses.map(course => (
            <div key={course.id} className="bg-card border border-border rounded-lg p-4 flex flex-col justify-between">
              <div>
                <h3 className="font-semibold text-lg">{course.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">You are enrolled in this course.</p>
              </div>
              <Button onClick={() => navigate(`/course/${course.slug}`)}>View Course</Button>
            </div>
          ))}
          {myCourses.length === 0 && (
             <div className="col-span-full text-center py-16 bg-card border border-border rounded-lg">
                <h3 className="text-2xl font-semibold mb-2">No Courses Yet</h3>
                <p className="text-muted-foreground mb-4">Browse our catalog and start your learning journey!</p>
                <Button onClick={() => navigate('/courses')}>Browse Courses</Button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default MyCourses;