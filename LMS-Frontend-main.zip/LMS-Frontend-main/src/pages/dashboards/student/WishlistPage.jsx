import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Heart, ShoppingCart, Trash2, Search } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';

const WishlistCard = ({ course, index }) => {
    const { toast } = useToast();

    const handleAction = (action) => {
        toast({
            title: `${action} '${course.title}'`,
            description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        });
    };

    const cardVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: {
            opacity: 1,
            y: 0,
            transition: {
                delay: index * 0.1,
            },
        },
    };

    return (
        <motion.div variants={cardVariants}>
            <Card className="h-full flex flex-col group overflow-hidden">
                <div className="relative">
                    <img class="w-full h-40 object-cover" alt={`Cover image for ${course.title}`} src="https://images.unsplash.com/photo-1677696795233-5ef097695f12" />
                    <div className="absolute top-2 right-2">
                        <Button variant="destructive" size="icon" className="h-8 w-8" onClick={() => handleAction('Removed')}>
                            <Trash2 className="h-4 w-4" />
                        </Button>
                    </div>
                </div>
                <CardHeader>
                    <CardTitle className="text-lg leading-tight h-12">{course.title}</CardTitle>
                    <CardDescription className="text-primary font-bold text-xl">${course.price}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow flex items-end">
                    <Button className="w-full" onClick={() => handleAction('Added to cart')}>
                        <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
                    </Button>
                </CardContent>
            </Card>
        </motion.div>
    );
};

const WishlistPage = () => {
    const { user } = useAuth();
    const { getWishlist } = useData();
    const wishlistItems = getWishlist(user.id);

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
            },
        },
    };

    return (
        <>
            <Helmet>
                <title>My Wishlist | Finchtalk</title>
                <meta name="description" content="Your saved courses, all in one place." />
            </Helmet>
            <div className="space-y-8">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                >
                    <div>
                        <h1 className="text-3xl md:text-4xl font-bold tracking-tight flex items-center gap-3">
                            <Heart className="w-8 h-8 text-primary" />
                            My Wishlist
                        </h1>
                        <p className="text-muted-foreground mt-2">Your saved courses, ready for you to start learning.</p>
                    </div>
                    <div className="relative w-full md:w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input placeholder="Search wishlist..." className="pl-10" />
                    </div>
                </motion.div>

                {wishlistItems.length > 0 ? (
                    <motion.div
                        variants={containerVariants}
                        initial="hidden"
                        animate="visible"
                        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
                    >
                        {wishlistItems.map((course, i) => (
                            <WishlistCard key={course.id} course={course} index={i} />
                        ))}
                    </motion.div>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="text-center py-20 bg-card rounded-lg border border-dashed"
                    >
                        <Heart className="mx-auto h-12 w-12 text-muted-foreground" />
                        <h3 className="mt-4 text-lg font-semibold">Your Wishlist is Empty</h3>
                        <p className="mt-1 text-sm text-muted-foreground">Browse our courses and save your favorites here.</p>
                        <Button asChild className="mt-6">
                           <Link to="/courses/browse">Browse Courses</Link>
                        </Button>
                    </motion.div>
                )}
            </div>
        </>
    );
};

export default WishlistPage;