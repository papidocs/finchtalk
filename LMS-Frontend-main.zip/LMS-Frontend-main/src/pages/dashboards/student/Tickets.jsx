import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { PlusCircle, Send, MessageSquare, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from '@/components/ui/dialog.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar.jsx';

const TicketDetails = ({ ticket, onBack }) => {
    const { addReplyToTicket } = useData();
    const [reply, setReply] = useState('');
    const [currentTicket, setCurrentTicket] = useState(ticket);

    const handleReply = () => {
        if (reply.trim()) {
            const updatedTicket = addReplyToTicket(currentTicket.id, reply);
            setCurrentTicket(updatedTicket);
            setReply('');
        }
    };

    return (
        <motion.div initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', stiffness: 300, damping: 30 }}>
            <Button variant="ghost" onClick={onBack} className="mb-4">
                <X className="w-4 h-4 mr-2" /> Back to Tickets
            </Button>
            <Card>
                <CardHeader>
                    <CardTitle>{currentTicket.subject}</CardTitle>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>Status: <Badge variant={currentTicket.status === 'Open' ? 'success' : 'secondary'}>{currentTicket.status}</Badge></span>
                        <span>Last Updated: {new Date(currentTicket.updated).toLocaleString()}</span>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6 max-h-[50vh] overflow-y-auto pr-4">
                        {currentTicket.messages.map((msg, index) => (
                            <div key={index} className={cn("flex items-end gap-3", msg.from === 'user' ? 'justify-end' : 'justify-start')}>
                                {msg.from === 'support' && <Avatar className="w-8 h-8"><AvatarFallback>S</AvatarFallback></Avatar>}
                                <div className={cn("max-w-md p-3 rounded-lg", msg.from === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted')}>
                                    <p className="text-sm">{msg.text}</p>
                                    <p className="text-xs opacity-70 mt-2 text-right">{new Date(msg.timestamp).toLocaleTimeString()}</p>
                                </div>
                                {msg.from === 'user' && <Avatar className="w-8 h-8"><AvatarFallback>U</AvatarFallback></Avatar>}
                            </div>
                        ))}
                    </div>
                    <div className="mt-6 border-t pt-6">
                        <Label htmlFor="reply" className="font-semibold">Your Reply</Label>
                        <Textarea id="reply" value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Type your message..." className="mt-2" />
                        <Button onClick={handleReply} className="mt-4">
                            <Send className="w-4 h-4 mr-2" /> Send Reply
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </motion.div>
    );
};

const Tickets = () => {
    const { user } = useAuth();
    const { getTicketsForUser, createTicket } = useData();
    const { toast } = useToast();
    const [tickets, setTickets] = useState(() => getTicketsForUser(user.id));
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [subject, setSubject] = useState('');
    const [message, setMessage] = useState('');
    const [selectedTicket, setSelectedTicket] = useState(null);

    const handleSubmit = () => {
        if (!subject || !message) {
            toast({ title: 'Error', description: 'Please fill out all fields.', variant: 'destructive' });
            return;
        }
        createTicket(user.id, subject, message);
        setTickets(getTicketsForUser(user.id));
        toast({ title: 'Success', description: 'Your ticket has been created.' });
        setIsDialogOpen(false);
        setSubject('');
        setMessage('');
    };

    const getStatusBadgeVariant = (status) => {
        switch (status) {
            case 'Open': return 'success';
            case 'Answered': return 'info';
            case 'Closed': return 'secondary';
            default: return 'secondary';
        }
    };

    return (
        <>
            <Helmet>
                <title>Support Tickets | Finchtalk</title>
            </Helmet>
            <div className="relative overflow-hidden">
                <AnimatePresence>
                    {selectedTicket ? (
                        <TicketDetails ticket={selectedTicket} onBack={() => setSelectedTicket(null)} />
                    ) : (
                        <motion.div initial={{ x: 0 }} animate={{ x: 0 }} exit={{ x: '-100%' }}>
                            <div className="flex justify-between items-center mb-6">
                                <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
                                    <MessageSquare className="w-8 h-8 text-primary" />
                                    Support Tickets
                                </h1>
                                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                                    <DialogTrigger asChild>
                                        <Button><PlusCircle className="w-4 h-4 mr-2" /> New Ticket</Button>
                                    </DialogTrigger>
                                    <DialogContent>
                                        <DialogHeader>
                                            <DialogTitle>Create New Support Ticket</DialogTitle>
                                            <DialogDescription>Describe your issue and our support team will get back to you.</DialogDescription>
                                        </DialogHeader>
                                        <div className="space-y-4 py-4">
                                            <div>
                                                <Label htmlFor="subject">Subject</Label>
                                                <Input id="subject" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="e.g., Issue with course video" />
                                            </div>
                                            <div>
                                                <Label htmlFor="message">Message</Label>
                                                <Textarea id="message" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Please describe your problem in detail..." />
                                            </div>
                                        </div>
                                        <DialogFooter>
                                            <Button onClick={handleSubmit}><Send className="w-4 h-4 mr-2" /> Submit Ticket</Button>
                                        </DialogFooter>
                                    </DialogContent>
                                </Dialog>
                            </div>
                            <Card>
                                <CardContent className="p-0">
                                    <div className="divide-y">
                                        {tickets.length > 0 ? tickets.map(ticket => (
                                            <div key={ticket.id} onClick={() => setSelectedTicket(ticket)} className="p-4 flex justify-between items-center hover:bg-muted/50 cursor-pointer transition-colors">
                                                <div>
                                                    <p className="font-semibold">{ticket.subject}</p>
                                                    <p className="text-sm text-muted-foreground">Last update: {new Date(ticket.updated).toLocaleDateString()}</p>
                                                </div>
                                                <Badge variant={getStatusBadgeVariant(ticket.status)}>{ticket.status}</Badge>
                                            </div>
                                        )) : (
                                            <div className="text-center py-12">
                                                <p className="text-muted-foreground">You haven't created any tickets yet.</p>
                                            </div>
                                        )}
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </>
    );
};

export default Tickets;