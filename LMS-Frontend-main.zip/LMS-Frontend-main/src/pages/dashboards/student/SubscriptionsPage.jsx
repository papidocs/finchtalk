import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CheckCircle, Star, Sparkles, CreditCard, XCircle, ArrowRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const plans = [
    {
        name: 'Basic',
        price: 'Free',
        price_monthly: 0,
        features: [
            'Access to free courses',
            'Limited workshop access',
            'Community support',
            'Standard learning materials'
        ],
        isCurrent: false,
    },
    {
        name: 'Pro',
        price: '$29 / month',
        price_monthly: 29,
        features: [
            'Unlimited access to all courses',
            'Full workshop access',
            'Priority support',
            'Exclusive content & projects',
            'Downloadable resources'
        ],
        isCurrent: true,
        isFeatured: true,
    },
    {
        name: 'Premium',
        price: '$79 / month',
        price_monthly: 79,
        features: [
            'All Pro features',
            '1-on-1 mentorship sessions',
            'Personalized career coaching',
            'Live project reviews',
            'Early access to new features'
        ],
        isCurrent: false,
    }
];


const SubscriptionsPage = () => {
  const { toast } = useToast();
  const currentPlan = plans.find(p => p.isCurrent);

  const handleAction = (action) => {
    toast({
      title: `${action}`,
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.95 },
    visible: { opacity: 1, scale: 1 }
  };

  return (
    <>
      <Helmet>
        <title>Manage Subscription | Finchtalk</title>
        <meta name="description" content="View and manage your Finchtalk subscription plan." />
      </Helmet>
      <motion.div
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className="space-y-8"
      >
        <motion.div variants={itemVariants}>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Manage Subscription</h1>
            <p className="text-muted-foreground mt-2">Upgrade, downgrade, or manage your billing details.</p>
        </motion.div>

        {currentPlan && (
            <motion.div variants={itemVariants}>
                <Card className="border-primary shadow-lg shadow-primary/10">
                    <CardHeader>
                        <div className="flex justify-between items-start">
                            <div>
                                <CardTitle className="text-2xl flex items-center gap-2">
                                    <Sparkles className="w-6 h-6 text-primary" />
                                    Your Current Plan
                                </CardTitle>
                                <CardDescription>You have an active Pro subscription.</CardDescription>
                            </div>
                            <span className="px-3 py-1 text-sm font-semibold rounded-full bg-green-500/20 text-green-400">Active</span>
                        </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center p-6 rounded-lg bg-muted/50">
                            <div>
                                <p className="text-3xl font-bold">{currentPlan.name}</p>
                                <p className="text-xl font-semibold text-primary">{currentPlan.price}</p>
                            </div>
                            <p className="text-sm text-muted-foreground mt-2 md:mt-0">Renews on December 5, 2025</p>
                        </div>
                        <div className="flex flex-col md:flex-row gap-4">
                            <Button className="w-full md:w-auto" onClick={() => handleAction('Manage Billing')}>
                                <CreditCard className="w-4 h-4 mr-2"/>
                                Manage Billing
                            </Button>
                             <Button variant="outline" className="w-full md:w-auto" onClick={() => handleAction('Cancel Subscription')}>
                                <XCircle className="w-4 h-4 mr-2"/>
                                Cancel Subscription
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </motion.div>
        )}

        <motion.div variants={itemVariants}>
            <h2 className="text-2xl font-bold tracking-tight">Available Plans</h2>
            <p className="text-muted-foreground mt-1">Choose the plan that's right for you.</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {plans.map(plan => (
                <motion.div key={plan.name} variants={itemVariants}>
                    <Card className={cn(
                        "flex flex-col h-full transition-all duration-300",
                        plan.isCurrent && "border-primary/50",
                        plan.isFeatured && !plan.isCurrent && "border-primary shadow-lg shadow-primary/10"
                    )}>
                        {plan.isFeatured && <div className="text-center py-1 bg-primary text-primary-foreground text-sm font-semibold rounded-t-lg">Most Popular</div>}
                        <CardHeader>
                            <CardTitle className="text-2xl">{plan.name}</CardTitle>
                            <CardDescription className="text-4xl font-bold text-foreground">{plan.price}</CardDescription>
                        </CardHeader>
                        <CardContent className="flex-grow flex flex-col">
                            <ul className="space-y-3 mb-8">
                                {plan.features.map(feature => (
                                    <li key={feature} className="flex items-start gap-3">
                                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 shrink-0" />
                                        <span>{feature}</span>
                                    </li>
                                ))}
                            </ul>
                            <div className="flex-grow" />
                            <Button 
                                className="w-full mt-auto group"
                                variant={plan.isCurrent ? 'secondary' : plan.isFeatured ? 'default' : 'outline'}
                                disabled={plan.isCurrent}
                                onClick={() => handleAction(plan.isCurrent ? '' : `Switch to ${plan.name}`)}
                            >
                                {plan.isCurrent ? 'Current Plan' : `Switch to ${plan.name}`}
                                {!plan.isCurrent && <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />}
                            </Button>
                        </CardContent>
                    </Card>
                </motion.div>
            ))}
        </div>
      </motion.div>
    </>
  );
};

export default SubscriptionsPage;