import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { UserPlus, Users, Search, Check, X, MessageSquare, UserX } from 'lucide-react';

import { getMockFriends, getMockFriendRequests, getMockFriendSuggestions } from '@/lib/mockApi';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/components/ui/use-toast';

const FriendCard = ({ user, type, index }) => {
  const { toast } = useToast();
  const handleAction = (action) => {
    toast({
      title: `${action} Friend`,
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const getInitials = (name = '') => name?.split(' ').map(n => n[0]).join('') || '';

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        delay: index * 0.08,
      },
    },
  };

  return (
    <motion.div variants={cardVariants}>
      <Card className="hover:shadow-lg transition-shadow duration-300">
        <CardContent className="p-4 flex items-center gap-4">
          <Avatar className="h-12 w-12 border-2 border-primary/50">
            <AvatarImage src={user.avatar} />
            <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <p className="font-semibold">{user.name}</p>
            <p className="text-sm text-muted-foreground">{user.status}</p>
          </div>
          <div className="flex gap-2">
            {type === 'friend' && (
              <>
                <Button variant="outline" size="icon" onClick={() => handleAction('Message')}>
                  <MessageSquare className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleAction('Remove')}>
                  <UserX className="h-4 w-4 text-destructive" />
                </Button>
              </>
            )}
            {type === 'request' && (
              <>
                <Button variant="default" size="icon" onClick={() => handleAction('Accept')}>
                  <Check className="h-4 w-4" />
                </Button>
                <Button variant="destructive" size="icon" onClick={() => handleAction('Decline')}>
                  <X className="h-4 w-4" />
                </Button>
              </>
            )}
            {type === 'suggestion' && (
              <Button size="sm" onClick={() => handleAction('Add')}>
                <UserPlus className="h-4 w-4 mr-2" /> Add
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};


const FriendsPage = () => {
  const friends = getMockFriends();
  const requests = getMockFriendRequests();
  const suggestions = getMockFriendSuggestions();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  return (
    <>
      <Helmet>
        <title>Friends | Finchtalk</title>
        <meta name="description" content="Connect with peers, invite new friends, and grow your network." />
      </Helmet>
      <div className="space-y-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight flex items-center gap-3">
              <Users className="w-8 h-8 text-primary" />
              Friends & Connections
            </h1>
            <p className="text-muted-foreground mt-2">Grow your network, find study partners, and collaborate.</p>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto">
             <div className="relative w-full md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search friends..." className="pl-10" />
            </div>
            <Button>
                <UserPlus className="h-4 w-4 mr-2" />
                Invite Friend
            </Button>
          </div>
        </motion.div>

        <Tabs defaultValue="friends" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="friends">My Friends ({friends.length})</TabsTrigger>
            <TabsTrigger value="requests" className="relative">
              Pending Requests ({requests.length})
              {requests.length > 0 && <span className="absolute top-1 right-2 h-2 w-2 rounded-full bg-primary" />}
            </TabsTrigger>
            <TabsTrigger value="suggestions">Find Friends ({suggestions.length})</TabsTrigger>
          </TabsList>
          
          <TabsContent value="friends">
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6"
            >
              {friends.map((friend, i) => (
                <FriendCard key={friend.id} user={friend} type="friend" index={i} />
              ))}
            </motion.div>
             {friends.length === 0 && <p className="text-center text-muted-foreground mt-10">You haven't added any friends yet. Find some in the "Find Friends" tab!</p>}
          </TabsContent>

          <TabsContent value="requests">
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6"
            >
              {requests.map((request, i) => (
                <FriendCard key={request.id} user={request} type="request" index={i} />
              ))}
            </motion.div>
             {requests.length === 0 && <p className="text-center text-muted-foreground mt-10">No pending friend requests.</p>}
          </TabsContent>

          <TabsContent value="suggestions">
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6"
            >
              {suggestions.map((suggestion, i) => (
                <FriendCard key={suggestion.id} user={suggestion} type="suggestion" index={i} />
              ))}
            </motion.div>
             {suggestions.length === 0 && <p className="text-center text-muted-foreground mt-10">We couldn't find any new friend suggestions right now. Check back later!</p>}
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default FriendsPage;