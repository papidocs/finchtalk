import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Award, CheckCircle, Flame, Gift, Search } from 'lucide-react';

import { getMockQuests } from '@/lib/mockApi';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';

const QuestIcon = ({ status }) => {
  if (status === 'completed') {
    return <CheckCircle className="w-8 h-8 text-green-500" />;
  }
  return <Flame className="w-8 h-8 text-orange-500" />;
};

const QuestCard = ({ quest, index }) => {
  const { toast } = useToast();
  const handleAction = () => {
    toast({
      title: "Let's go!",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        delay: index * 0.1,
      },
    },
  };

  return (
    <motion.div variants={cardVariants}>
      <Card className="h-full flex flex-col group hover:border-primary transition-all duration-300 transform hover:-translate-y-1 hover:shadow-xl">
        <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-4">
          <QuestIcon status={quest.status} />
          <div className="flex-1">
            <CardTitle className="text-lg">{quest.title}</CardTitle>
            <p className="text-sm text-muted-foreground">{quest.description}</p>
          </div>
        </CardHeader>
        <CardContent className="flex-grow flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-muted-foreground">Progress</span>
              <span className="text-sm font-bold">{quest.progress}%</span>
            </div>
            <Progress value={quest.progress} className="h-2" />
          </div>
          <div className="mt-4">
            <div className="flex items-center gap-2 text-sm text-amber-500 font-semibold">
              <Gift className="w-4 h-4" />
              <span>{quest.reward}</span>
            </div>
          </div>
        </CardContent>
        <div className="p-6 pt-0">
          <Button onClick={handleAction} className="w-full" disabled={quest.status === 'completed'}>
            {quest.status === 'completed' ? 'Completed' : quest.status === 'active' ? 'Continue Quest' : 'Start Quest'}
          </Button>
        </div>
      </Card>
    </motion.div>
  );
};

const QuestsPage = () => {
  const quests = getMockQuests();
  const activeQuests = quests.filter(q => q.status === 'active');
  const availableQuests = quests.filter(q => q.status === 'available');
  const completedQuests = quests.filter(q => q.status === 'completed');

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  return (
    <>
      <Helmet>
        <title>Quests | Finchtalk</title>
        <meta name="description" content="Embark on quests, earn rewards, and level up your skills." />
      </Helmet>
      <div className="space-y-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight flex items-center gap-3">
              <Award className="w-8 h-8 text-primary" />
              Quests & Challenges
            </h1>
            <p className="text-muted-foreground mt-2">Embark on learning journeys, earn rewards, and showcase your skills.</p>
          </div>
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search quests..." className="pl-10" />
          </div>
        </motion.div>

        <Tabs defaultValue="active" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="active">Active ({activeQuests.length})</TabsTrigger>
            <TabsTrigger value="available">Available ({availableQuests.length})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({completedQuests.length})</TabsTrigger>
          </TabsList>
          
          <TabsContent value="active">
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6"
            >
              {activeQuests.map((quest, i) => (
                <QuestCard key={quest.id} quest={quest} index={i} />
              ))}
            </motion.div>
             {activeQuests.length === 0 && <p className="text-center text-muted-foreground mt-10">No active quests. Start one from the "Available" tab!</p>}
          </TabsContent>

          <TabsContent value="available">
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6"
            >
              {availableQuests.map((quest, i) => (
                <QuestCard key={quest.id} quest={quest} index={i} />
              ))}
            </motion.div>
             {availableQuests.length === 0 && <p className="text-center text-muted-foreground mt-10">You've explored all available quests for now. Check back soon!</p>}
          </TabsContent>

          <TabsContent value="completed">
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6"
            >
              {completedQuests.map((quest, i) => (
                <QuestCard key={quest.id} quest={quest} index={i} />
              ))}
            </motion.div>
             {completedQuests.length === 0 && <p className="text-center text-muted-foreground mt-10">No quests completed yet. Keep learning!</p>}
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default QuestsPage;