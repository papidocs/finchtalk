import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Folder, FileText, ChevronRight, MoreVertical, Upload, FolderPlus, FilePlus, Trash2, BrainCircuit, Search, X } from 'lucide-react';
import { getMockDriveItems } from '@/lib/mockApi';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const buildFileTree = (items) => {
  const tree = [];
  const map = {};
  items.forEach(item => {
    map[item.id] = { ...item, children: [] };
  });

  items.forEach(item => {
    if (item.parentId) {
      if(map[item.parentId]) {
        map[item.parentId].children.push(map[item.id]);
      }
    } else {
      tree.push(map[item.id]);
    }
  });

  return tree;
};

const FileTree = ({ items, onSelect, selectedId, level = 0 }) => {
  const [openFolders, setOpenFolders] = useState({});

  const toggleFolder = (folderId) => {
    setOpenFolders(prev => ({ ...prev, [folderId]: !prev[folderId] }));
  };

  return (
    <div>
      {items.map(item => (
        <div key={item.id}>
          <div
            className={cn(
              "flex items-center gap-2 py-1.5 px-2 rounded-md cursor-pointer hover:bg-muted",
              selectedId === item.id && 'bg-primary/10 text-primary'
            )}
            style={{ paddingLeft: `${level * 1.5 + 0.5}rem` }}
            onClick={() => {
              if (item.type === 'folder') toggleFolder(item.id);
              onSelect(item);
            }}
          >
            {item.type === 'folder' && (
              <ChevronRight
                className={cn("w-4 h-4 transition-transform", openFolders[item.id] && 'rotate-90')}
              />
            )}
            {item.type === 'folder' ? <Folder className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
            <span className="flex-1 truncate text-sm">{item.name}</span>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>
                  <Trash2 className="w-4 h-4 mr-2" /> Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          {item.type === 'folder' && openFolders[item.id] && item.children.length > 0 && (
            <FileTree items={item.children} onSelect={onSelect} selectedId={selectedId} level={level + 1} />
          )}
        </div>
      ))}
    </div>
  );
};

const DrivePage = () => {
  const { toast } = useToast();
  const driveItems = getMockDriveItems();
  const fileTree = useMemo(() => buildFileTree(driveItems), [driveItems]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [noteContent, setNoteContent] = useState('');

  const handleSelect = (item) => {
    setSelectedItem(item);
    if (item.type === 'file') {
      setNoteContent(item.content || '');
    }
  };
  
  const handleAction = (action) => {
    toast({
      title: `${action}`,
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <>
      <Helmet>
        <title>Workspace Drive | Finchtalk</title>
        <meta name="description" content="Your personal workspace for notes, files, and AI-powered insights." />
      </Helmet>
      <div className="flex h-[calc(100vh-8rem)] bg-background rounded-lg border overflow-hidden">
        {/* Sidebar */}
        <div className="w-1/4 min-w-[250px] max-w-[350px] bg-muted/30 border-r flex flex-col">
          <div className="p-3 border-b">
            <h2 className="text-lg font-semibold">Workspace</h2>
            <p className="text-xs text-muted-foreground">Your personal drive</p>
          </div>
          <div className="p-2 flex gap-1">
             <Button variant="ghost" size="icon" onClick={() => handleAction('New Note')}><FilePlus className="h-4 w-4" /></Button>
             <Button variant="ghost" size="icon" onClick={() => handleAction('New Folder')}><FolderPlus className="h-4 w-4" /></Button>
             <Button variant="ghost" size="icon" onClick={() => handleAction('Upload')}><Upload className="h-4 w-4" /></Button>
          </div>
          <div className="flex-1 overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-muted-foreground/50">
            <FileTree items={fileTree} onSelect={handleSelect} selectedId={selectedItem?.id} />
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          <AnimatePresence mode="wait">
            {!selectedItem ? (
              <motion.div
                key="empty"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="flex flex-col items-center justify-center h-full text-center p-8"
              >
                <Folder className="w-24 h-24 text-muted-foreground/30 mb-4" />
                <h3 className="text-xl font-semibold">Select a file or folder</h3>
                <p className="text-muted-foreground">Your notes and documents will appear here.</p>
              </motion.div>
            ) : selectedItem.type === 'folder' ? (
              <motion.div
                key="folder"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-full text-center p-8"
              >
                <Folder className="w-24 h-24 text-muted-foreground/30 mb-4" />
                <h3 className="text-xl font-semibold">{selectedItem.name}</h3>
                <p className="text-muted-foreground">This folder contains {selectedItem.children.length} items.</p>
              </motion.div>
            ) : (
              <motion.div
                key={selectedItem.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex-1 flex flex-col"
              >
                <div className="p-3 border-b flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4" />
                        <h3 className="font-medium">{selectedItem.name}</h3>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => setSelectedItem(null)}>
                        <X className="h-4 w-4" />
                    </Button>
                </div>
                <div className="flex-1 flex">
                    <Textarea
                        value={noteContent}
                        onChange={(e) => setNoteContent(e.target.value)}
                        placeholder="Start typing your notes here..."
                        className="w-full h-full border-0 resize-none focus-visible:ring-0 p-4 bg-transparent text-base"
                    />
                    <div className="w-[300px] border-l bg-muted/30 p-4 flex flex-col">
                        <div className="flex items-center gap-2 mb-4">
                           <BrainCircuit className="w-6 h-6 text-primary" />
                           <h4 className="font-bold text-lg">NotebookLM</h4>
                        </div>
                        <p className="text-sm text-muted-foreground mb-4">Your AI assistant for these notes.</p>
                        <Button onClick={() => handleAction('Ask AI Assistant')}>
                            <Search className="w-4 h-4 mr-2" />
                            Ask Assistant
                        </Button>
                    </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </>
  );
};

export default DrivePage;