import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Calendar, Clock, User, Users, Tag, CheckCircle, ArrowRight, Search } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';

const WorkshopCard = ({ workshop, isRegistered, isPast, index }) => {
    const { toast } = useToast();
    const handleRegister = () => {
        toast({
            title: `Registering for ${workshop.title}`,
            description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        });
    };

    const cardVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: {
            opacity: 1,
            y: 0,
            transition: {
                delay: index * 0.1,
            },
        },
    };

    const capacityPercentage = (workshop.enrolled / workshop.capacity) * 100;
    const isFull = workshop.enrolled >= workshop.capacity;

    return (
        <motion.div variants={cardVariants}>
            <Card className="h-full flex flex-col group hover:border-primary transition-all duration-300 transform hover:-translate-y-1 hover:shadow-xl">
                <CardHeader>
                    <CardTitle className="text-xl">{workshop.title}</CardTitle>
                    <CardDescription className="flex items-center gap-2 pt-1">
                        <Calendar className="w-4 h-4" />
                        {new Date(workshop.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                    </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow flex flex-col">
                    <div className="space-y-3 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2"><Clock className="w-4 h-4" />{workshop.duration}</div>
                        <div className="flex items-center gap-2"><User className="w-4 h-4" />Instructor: {workshop.instructor}</div>
                        <div className="flex items-center gap-2"><Tag className="w-4 h-4" />${workshop.price}</div>
                    </div>
                    <div className="mt-4">
                        <div className="flex justify-between items-center text-sm mb-1">
                            <span className="flex items-center gap-2"><Users className="w-4 h-4" /> {workshop.enrolled} / {workshop.capacity}</span>
                            <span className={cn("font-semibold", isFull ? "text-red-500" : "text-primary")}>{isFull ? 'Full' : 'Spots available'}</span>
                        </div>
                        <Progress value={capacityPercentage} className="h-2" />
                    </div>
                </CardContent>
                <div className="p-6 pt-0">
                    <Button 
                        className="w-full group/btn"
                        onClick={handleRegister}
                        disabled={isRegistered || isFull || isPast}
                    >
                        {isPast ? 'View Recording' : isRegistered ? <><CheckCircle className="w-4 h-4 mr-2" /> Registered</> : isFull ? 'Workshop Full' : 'Register Now'}
                        {!isRegistered && !isFull && <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover/btn:translate-x-1" />}
                    </Button>
                </div>
            </Card>
        </motion.div>
    );
};

const WorkshopsPage = () => {
    const { user } = useAuth();
    const { getWorkshops, getRegisteredWorkshops } = useData();
    
    const allWorkshops = getWorkshops();
    const myRegisteredWorkshops = getRegisteredWorkshops(user.id);
    const myRegisteredWorkshopIds = myRegisteredWorkshops.map(w => w.id);

    const now = new Date();
    const upcomingWorkshops = allWorkshops.filter(w => new Date(w.date) >= now);
    const pastWorkshops = allWorkshops.filter(w => new Date(w.date) < now);

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
    };

    return (
        <>
            <Helmet>
                <title>Workshops | Finchtalk</title>
                <meta name="description" content="Join live workshops, interact with instructors, and enhance your skills." />
            </Helmet>
            <div className="space-y-8">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                >
                    <div>
                        <h1 className="text-3xl md:text-4xl font-bold tracking-tight flex items-center gap-3">
                            <Calendar className="w-8 h-8 text-primary" />
                            Workshops & Live Events
                        </h1>
                        <p className="text-muted-foreground mt-2">Join live sessions, interact with experts, and accelerate your learning.</p>
                    </div>
                    <div className="relative w-full md:w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input placeholder="Search workshops..." className="pl-10" />
                    </div>
                </motion.div>

                <Tabs defaultValue="upcoming" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="upcoming">Upcoming ({upcomingWorkshops.length})</TabsTrigger>
                        <TabsTrigger value="registered">My Registered ({myRegisteredWorkshops.filter(w => new Date(w.date) >= now).length})</TabsTrigger>
                        <TabsTrigger value="past">Past Workshops ({pastWorkshops.length})</TabsTrigger>
                    </TabsList>

                    <TabsContent value="upcoming">
                        <motion.div
                            variants={containerVariants}
                            initial="hidden"
                            animate="visible"
                            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6"
                        >
                            {upcomingWorkshops.map((workshop, i) => (
                                <WorkshopCard key={workshop.id} workshop={workshop} isRegistered={myRegisteredWorkshopIds.includes(workshop.id)} isPast={false} index={i} />
                            ))}
                        </motion.div>
                        {upcomingWorkshops.length === 0 && <p className="text-center text-muted-foreground mt-10">No upcoming workshops scheduled. Check back soon!</p>}
                    </TabsContent>

                    <TabsContent value="registered">
                        <motion.div
                            variants={containerVariants}
                            initial="hidden"
                            animate="visible"
                            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6"
                        >
                            {myRegisteredWorkshops.filter(w => new Date(w.date) >= now).map((workshop, i) => (
                                <WorkshopCard key={workshop.id} workshop={workshop} isRegistered={true} isPast={false} index={i} />
                            ))}
                        </motion.div>
                        {myRegisteredWorkshops.filter(w => new Date(w.date) >= now).length === 0 && <p className="text-center text-muted-foreground mt-10">You haven't registered for any upcoming workshops yet.</p>}
                    </TabsContent>

                    <TabsContent value="past">
                        <motion.div
                            variants={containerVariants}
                            initial="hidden"
                            animate="visible"
                            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6"
                        >
                            {pastWorkshops.map((workshop, i) => (
                                <WorkshopCard key={workshop.id} workshop={workshop} isRegistered={myRegisteredWorkshopIds.includes(workshop.id)} isPast={true} index={i} />
                            ))}
                        </motion.div>
                        {pastWorkshops.length === 0 && <p className="text-center text-muted-foreground mt-10">No workshops have concluded yet.</p>}
                    </TabsContent>
                </Tabs>
            </div>
        </>
    );
};

export default WorkshopsPage;