import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, useSpring, useTransform } from 'framer-motion';
import { Award, Crown, Flame, Users, Trophy, Star, Zap, BookOpen, GitMerge, Gift, UserPlus, Milestone, ArrowRight, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useData } from '@/context/DataContext';
import { useAuth } from '@/context/AuthContext';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Button } from '@/components/ui/button';

// ---------- helpers & fallbacks ----------
const ensureArray = (v) => (Array.isArray(v) ? v : []);

const demoLeaderboard = [
  { id: 'u1', handle: 'A. Sharma', avatar: '', level: 6, hp: 3580, streak: 9, topCategory: 'Cloud', badges: ['aws','streak-7','quiz-master','quest-master'] },
  { id: 'u2', handle: 'S. Lee',    avatar: '', level: 6, hp: 3490, streak: 7, topCategory: 'AI',    badges: ['ai','streak-7','hackathon-winner'] },
  { id: 'u3', handle: 'N. Tan',    avatar: '', level: 5, hp: 3210, streak: 3, topCategory: 'Data',  badges: ['data','quiz-master'] },
  { id: 'u4', handle: 'R. Gupta',  avatar: '', level: 5, hp: 2990, streak: 6, topCategory: 'DevOps',badges: ['devops','streak-7'] },
  { id: 'demo-user', handle: 'Demo User', avatar: '', level: 4, hp: 2120, streak: 2, topCategory: 'Security', badges: ['security'] },
];

const levelThresholds = [0, 200, 500, 1000, 2000, 3500, 5500];
const rankTiers = {
  Bronze:   [0, 499],
  Silver:   [500, 1499],
  Gold:     [1500, 3499],
  Platinum: [3500, 6999],
  Diamond:  [7000, Infinity],
};

const getRankTier = (hp = 0) => {
  for (const tier in rankTiers) {
    const [min, max] = rankTiers[tier];
    if (hp >= min && hp <= max) return tier;
  }
  return 'Bronze';
};

const AnimatedNumber = ({ value = 0 }) => {
  const spring = useSpring(0, { mass: 0.8, stiffness: 100, damping: 15 });
  const display = useTransform(spring, (current) => Math.round(current).toLocaleString());
  useEffect(() => { spring.set(value || 0); }, [spring, value]);
  return <motion.span>{display}</motion.span>;
};

const RankChip = ({ rank }) => {
  const rankStyles = {
    Diamond: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
    Platinum: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    Gold: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    Silver: 'bg-slate-400/10 text-slate-300 border-slate-400/30',
    Bronze: 'bg-orange-700/10 text-orange-500 border-orange-700/30',
  };
  return (
    <div className={cn('px-3 py-1 text-sm font-bold rounded-full border', rankStyles[rank] || rankStyles.Bronze)}>
      {rank}
    </div>
  );
};

const BadgeIcon = ({ badge, size = 'sm' }) => {
  const badgeInfo = {
    'aws': { icon: <Zap />, label: 'AWS Pro' },
    'devops': { icon: <Shield />, label: 'DevOps Master' },
    'ai': { icon: <Star />, label: 'AI Whiz' },
    'sre': { icon: <Shield />, label: 'SRE Expert' },
    'data': { icon: <Zap />, label: 'Data Dynamo' },
    'web': { icon: <Zap />, label: 'Full Stack Hero' },
    'security': { icon: <Shield />, label: 'Security Sentinel' },
    'gcp': { icon: <Zap />, label: 'GCP Guru' },
    'streak-7': { icon: <Flame />, label: '7-Day Streak' },
    'streak-30': { icon: <Flame />, label: '30-Day Streak' },
    'hackathon-winner': { icon: <Trophy />, label: 'Hackathon Winner' },
    'quest-master': { icon: <Trophy />, label: 'Quest Master' },
    'quiz-master': { icon: <Trophy />, label: 'Quiz Master' },
  };
  const info = badgeInfo[badge] || { icon: <Star />, label: 'Badge' };
  const sizeClasses = size === 'sm' ? 'w-5 h-5' : 'w-8 h-8';
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger>
          <div className="rounded-full flex items-center justify-center text-primary">
            {React.cloneElement(info.icon, { className: sizeClasses })}
          </div>
        </TooltipTrigger>
        <TooltipContent><p>{info.label}</p></TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

const Sparkline = () => (
  <svg width="100" height="30" className="opacity-20" stroke="currentColor" strokeWidth="2" fill="none">
    <path d="M 0 25 C 10 10, 20 10, 30 15 S 50 25, 60 20 S 80 5, 90 10 S 100 20, 100 20" />
  </svg>
);

const ActivityTile = ({ icon, title, total = 0, week = 0, hp = 0, tooltipContent }) => (
  <TooltipProvider>
    <Tooltip>
      <TooltipTrigger asChild>
        <motion.div whileHover={{ y: -5, scale: 1.02 }} className="relative overflow-hidden rounded-2xl p-4 bg-white/5 backdrop-blur-sm border border-white/10 shadow-lg flex flex-col justify-between h-full">
          <div className="flex justify-between items-start">
            <div className="p-2 bg-primary/10 rounded-lg">{icon}</div>
            <div className="text-right">
              <p className="text-2xl font-bold">{total}</p>
              <p className="text-xs text-primary">+{week} this week</p>
            </div>
          </div>
          <div className="mt-4">
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-lg font-semibold">{(hp || 0).toLocaleString()} HP</p>
          </div>
          <div className="absolute bottom-0 right-0"><Sparkline /></div>
        </motion.div>
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-xs text-center">{tooltipContent}</TooltipContent>
    </Tooltip>
  </TooltipProvider>
);

const activityData = [
  { icon: <BookOpen className="w-6 h-6 text-primary" />, title: "Workshops", total: 8, week: 1, hp: 380, tooltip: "50 HP (live) / 30 HP (recording)" },
  { icon: <GitMerge className="w-6 h-6 text-primary" />, title: "Quests", total: 22, week: 3, hp: 520, tooltip: "20 HP (regular) / 40 HP (advanced)" },
  { icon: <Zap className="w-6 h-6 text-primary" />, title: "Quizzes", total: 45, week: 5, hp: 615, tooltip: "10 HP (≥70%) | +5 HP (≥90%) | +20 HP (100% first try)" },
  { icon: <Award className="w-6 h-6 text-primary" />, title: "Courses", total: 3, week: 0, hp: 700, tooltip: "100–300 HP based on length" },
  { icon: <Trophy className="w-6 h-6 text-primary" />, title: "Hackathons", total: 1, week: 0, hp: 150, tooltip: "150 HP (participate) | +150 HP (Top 10%) | +300 HP (podium)" },
  { icon: <Milestone className="w-6 h-6 text-primary" />, title: "Milestones", total: 2, week: 0, hp: 50, tooltip: "+25 HP first workshop/course, +100 HP first hackathon" },
  { icon: <UserPlus className="w-6 h-6 text-primary" />, title: "Referrals", total: 0, week: 0, hp: 0, tooltip: "+50 HP per verified signup" },
];

const SeasonCountdown = () => {
  const calculateTimeLeft = () => {
    const end = new Date('2025-12-01T00:00:00Z').getTime();
    const now = Date.now();
    const diff = end - now;
    if (diff <= 0) return { days: 0, hours: 0, minutes: 0 };
    return {
      days: Math.floor(diff / (1000 * 60 * 60 * 24)),
      hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
      minutes: Math.floor((diff / 1000 / 60) % 60),
    };
  };
  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());
  useEffect(() => {
    const t = setInterval(() => setTimeLeft(calculateTimeLeft()), 60_000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="flex gap-4">
      {Object.entries(timeLeft).map(([k, v]) => (
        <div key={k} className="text-center">
          <p className="text-2xl font-bold">{v}</p>
          <p className="text-xs uppercase text-muted-foreground">{k}</p>
        </div>
      ))}
    </div>
  );
};

// ---------- main page ----------
const LeaderboardPage = () => {
  const { user: ctxUser } = useAuth();
  const { getLeaderboard } = useData();

  const user = ctxUser || { id: 'demo-user', handle: 'Demo User' };
  const [filters, setFilters] = useState({ range: 'all', scope: 'global' });

  const leaderboardData = useMemo(() => {
    try {
      const res = ensureArray(getLeaderboard(filters));
      return res.length ? res : demoLeaderboard;
    } catch {
      return demoLeaderboard;
    }
  }, [getLeaderboard, filters]);

  const allTimeLeaderboard = useMemo(() => {
    try {
      const res = ensureArray(getLeaderboard({ range: 'all', scope: 'global' }));
      return res.length ? res : demoLeaderboard;
    } catch {
      return demoLeaderboard;
    }
  }, [getLeaderboard]);

  const currentUserData =
    leaderboardData.find(u => u.id === user.id) ||
    allTimeLeaderboard.find(u => u.id === user.id) ||
    demoLeaderboard.find(u => u.id === 'demo-user');

  if (!currentUserData) {
    return (
      <div className="flex items-center justify-center h-96 text-muted-foreground">
        No leaderboard data available (demo).
      </div>
    );
  }

  const currentUserRankIndex = leaderboardData.findIndex(u => u.id === user.id);
  const currentUserRank = currentUserRankIndex >= 0 ? currentUserRankIndex + 1 : '-';

  const level = currentUserData.level || 1;
  const prevXp = levelThresholds[level - 1] ?? 0;
  const nextXp = levelThresholds[level] ?? (currentUserData.hp + 1);
  const denom = Math.max(1, nextXp - prevXp);
  const levelProgress = Math.min(100, Math.max(0, ((currentUserData.hp - prevXp) / denom) * 100));

  return (
    <>
      <Helmet>
        <title>Leaderboard | Finchtalk</title>
        <meta name="description" content="See where you stand on the Finchtalk leaderboard." />
      </Helmet>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
        <div className="flex items-center gap-4">
          <Trophy className="w-10 h-10 text-primary" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Leaderboard</h1>
            <p className="text-muted-foreground">See where you stand and climb the ranks!</p>
          </div>
        </div>

        <Card className="bg-gradient-to-br from-primary/5 to-transparent">
          <CardContent className="p-6 flex flex-col md:flex-row items-center gap-6">
            <div className="relative">
              <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 120 120" aria-hidden="true">
                <circle cx="60" cy="60" r="54" fill="none" stroke="hsl(var(--border))" strokeWidth="8" />
                <motion.circle
                  cx="60" cy="60" r="54" fill="none"
                  stroke="hsl(var(--primary))" strokeWidth="8" strokeLinecap="round"
                  pathLength="100"
                  initial={{ strokeDasharray: "0 100" }}
                  animate={{ strokeDasharray: `${levelProgress} 100` }}
                  transition={{ duration: 1.2, ease: "easeInOut" }}
                />
              </svg>
              <Avatar className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 border-4 border-background">
                <AvatarImage src={currentUserData.avatar || ''} />
                <AvatarFallback>{(currentUserData.handle || 'DU').slice(0, 2)}</AvatarFallback>
              </Avatar>
            </div>

            <div className="flex-1 text-center md:text-left">
              <h2 className="text-2xl font-bold">{currentUserData.handle}</h2>
              <div className="flex items-center justify-center md:justify-start gap-4 mt-1">
                <RankChip rank={getRankTier(currentUserData.hp)} />
                <p className="font-semibold">Level {level}</p>
              </div>
            </div>

            <div className="flex items-center gap-8 text-center">
              <div>
                <p className="text-sm text-muted-foreground">Rank</p>
                <p className="text-3xl font-bold">#{currentUserRank}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total HP</p>
                <p className="text-3xl font-bold text-primary"><AnimatedNumber value={currentUserData.hp} /></p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Streak</p>
                <p className="text-3xl font-bold flex items-center gap-1">
                  {currentUserData.streak || 0} <Flame className="w-6 h-6 text-red-500" />
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-2 bg-gradient-to-tr from-card to-muted/20">
            <CardHeader>
              <CardTitle>Season Ends In</CardTitle>
              <CardDescription>November 2025 Season</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-between items-center">
              <SeasonCountdown />
              <div className="text-right">
                <p className="font-semibold">Top 1% Reward</p>
                <p className="text-sm text-primary flex items-center gap-2 justify-end">
                  <Gift className="w-4 h-4"/>
                  Exclusive Badge & Swag
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="flex flex-col justify-center items-center p-6 bg-primary/10 hover:bg-primary/20 transition-colors">
            <h3 className="text-xl font-bold text-center">Ready to climb?</h3>
            <p className="text-muted-foreground text-center mt-1 mb-4">Jump into an activity.</p>
            <div className="flex gap-2">
              <Button asChild variant="outline" size="sm"><Link to="/dashboard/quests">Start Quest <ArrowRight className="w-4 h-4 ml-2"/></Link></Button>
              <Button asChild variant="outline" size="sm"><Link to="/dashboard/workshops">Join Workshop <ArrowRight className="w-4 h-4 ml-2"/></Link></Button>
            </div>
          </Card>
        </div>

        <div>
          <h2 className="text-2xl font-bold tracking-tight mb-4">Points & Activity</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
            {activityData.map((it) => (
              <ActivityTile
                key={it.title}
                icon={it.icon}
                title={it.title}
                total={it.total}
                week={it.week}
                hp={it.hp}
                tooltipContent={it.tooltip}
              />
            ))}
          </div>
        </div>

        <Card>
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <CardTitle>Rankings</CardTitle>
              <div className="flex gap-2">
                <Tabs value={filters.range} onValueChange={(v) => setFilters(f => ({ ...f, range: v }))}>
                  <TabsList>
                    <TabsTrigger value="week">Week</TabsTrigger>
                    <TabsTrigger value="month">Month</TabsTrigger>
                    <TabsTrigger value="all">All-Time</TabsTrigger>
                  </TabsList>
                </Tabs>
                <Tabs value={filters.scope} onValueChange={(v) => setFilters(f => ({ ...f, scope: v }))}>
                  <TabsList>
                    <TabsTrigger value="global"><Users className="w-4 h-4 mr-2" />Global</TabsTrigger>
                    <TabsTrigger value="friends"><Users className="w-4 h-4 mr-2" />Friends</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="hidden md:flex items-center text-xs text-muted-foreground font-semibold px-3 py-2 border-b">
              <div className="w-10 text-center">#</div>
              <div className="flex-1 ml-4">USER</div>
              <div className="w-32 text-center">STREAK</div>
              <div className="w-32 text-center">TOP CATEGORY</div>
              <div className="w-48 text-center">BADGES</div>
              <div className="w-20 text-right">HP</div>
            </div>

            <div className="space-y-1">
              {leaderboardData.map((player, index) => (
                <motion.div
                  key={player.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={cn(
                    "flex items-center p-3 rounded-lg transition-colors",
                    player.id === user.id ? 'bg-primary/10' : 'hover:bg-muted/50'
                  )}
                >
                  <div className="w-10 text-center text-lg font-bold text-muted-foreground">
                    {index < 3 ? (
                      <Crown
                        className={cn('w-6 h-6 mx-auto',
                          index === 0 && 'text-amber-400',
                          index === 1 && 'text-slate-400',
                          index === 2 && 'text-orange-600'
                        )}
                      />
                    ) : index + 1}
                  </div>

                  <div className="flex items-center gap-3 flex-1 ml-4">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={player.avatar || ''} />
                      <AvatarFallback>{(player.handle || 'U').slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{player.handle}</p>
                      <p className="text-sm text-muted-foreground md:hidden">Level {player.level || 1} • {(player.hp || 0).toLocaleString()} HP</p>
                    </div>
                  </div>

                  <div className="hidden md:flex items-center justify-center w-32 text-center">
                    <span className="font-semibold mr-1">{player.streak || 0}</span>
                    <Flame className={cn('w-4 h-4', (player.streak || 0) > 0 ? 'text-red-500' : 'text-muted-foreground/50')} />
                  </div>

                  <div className="hidden md:flex justify-center w-32 font-medium text-sm text-center">
                    {player.topCategory || '—'}
                  </div>

                  <div className="hidden md:flex items-center justify-center gap-3 w-48">
                    {ensureArray(player.badges).slice(0, 4).map(b => <BadgeIcon key={b} badge={b} />)}
                  </div>

                  <div className="hidden md:block w-20 text-right font-bold text-primary">
                    {(player.hp || 0).toLocaleString()} HP
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </>
  );
};

export default LeaderboardPage;