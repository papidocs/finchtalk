import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { FileQuestion, Clock, HelpCircle, CheckCircle, Percent, ArrowRight, Search, Zap } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';

const QuizCard = ({ quiz, index }) => {
    const { toast } = useToast();

    const handleAction = () => {
        toast({
            title: "Let's start the quiz!",
            description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        });
    };

    const cardVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: {
            opacity: 1,
            y: 0,
            transition: {
                delay: index * 0.1,
            },
        },
    };
    
    const getStatusInfo = (status) => {
        switch (status) {
            case 'completed':
                return {
                    label: 'View Results',
                    icon: <CheckCircle className="mr-2 h-4 w-4" />,
                    disabled: false
                };
            case 'in-progress':
                 return {
                    label: 'Continue Quiz',
                    icon: <ArrowRight className="mr-2 h-4 w-4" />,
                    disabled: false
                };
            default:
                 return {
                    label: 'Start Quiz',
                    icon: <Zap className="mr-2 h-4 w-4" />,
                    disabled: false
                };
        }
    };
    
    const statusInfo = getStatusInfo(quiz.status);

    return (
        <motion.div variants={cardVariants}>
            <Card className="h-full flex flex-col group hover:border-primary transition-all duration-300 transform hover:-translate-y-1 hover:shadow-xl">
                <CardHeader>
                    <CardTitle className="text-lg">{quiz.title}</CardTitle>
                    <CardDescription>From: {quiz.courseId.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow flex flex-col justify-between">
                    <div className="space-y-3 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2"><HelpCircle className="w-4 h-4" />{quiz.questions} Questions</div>
                        <div className="flex items-center gap-2"><Clock className="w-4 h-4" />{quiz.duration} Minutes</div>
                        {quiz.status === 'completed' && (
                            <div className="flex items-center gap-2 pt-2"><Percent className="w-4 h-4 text-primary" /><span className="text-primary font-bold">Score: {quiz.score}%</span></div>
                        )}
                         {quiz.status === 'in-progress' && (
                            <div className="pt-2">
                                <div className="flex items-center justify-between mb-1">
                                    <span className="text-sm font-medium text-muted-foreground">Progress</span>
                                    <span className="text-sm font-bold">{quiz.progress}%</span>
                                </div>
                                <Progress value={quiz.progress} className="h-2" />
                            </div>
                        )}
                    </div>
                </CardContent>
                <div className="p-6 pt-0">
                    <Button onClick={handleAction} className="w-full">
                        {statusInfo.icon}
                        {statusInfo.label}
                    </Button>
                </div>
            </Card>
        </motion.div>
    );
};

const QuizzesPage = () => {
    const { getQuizzes } = useData();
    const quizzes = getQuizzes();
    
    const availableQuizzes = quizzes.filter(q => q.status === 'available');
    const inProgressQuizzes = quizzes.filter(q => q.status === 'in-progress');
    const completedQuizzes = quizzes.filter(q => q.status === 'completed');

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
            },
        },
    };

    return (
        <>
            <Helmet>
                <title>Quizzes | Finchtalk</title>
                <meta name="description" content="Test your knowledge with quizzes for your courses." />
            </Helmet>
            <div className="space-y-8">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                >
                    <div>
                        <h1 className="text-3xl md:text-4xl font-bold tracking-tight flex items-center gap-3">
                            <FileQuestion className="w-8 h-8 text-primary" />
                            Quizzes
                        </h1>
                        <p className="text-muted-foreground mt-2">Test your knowledge and earn points towards your rank.</p>
                    </div>
                    <div className="relative w-full md:w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input placeholder="Search quizzes..." className="pl-10" />
                    </div>
                </motion.div>

                <Tabs defaultValue="available" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="available">Available ({availableQuizzes.length})</TabsTrigger>
                        <TabsTrigger value="in-progress">In Progress ({inProgressQuizzes.length})</TabsTrigger>
                        <TabsTrigger value="completed">Completed ({completedQuizzes.length})</TabsTrigger>
                    </TabsList>

                    <TabsContent value="available">
                        <motion.div
                            variants={containerVariants}
                            initial="hidden"
                            animate="visible"
                            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6"
                        >
                            {availableQuizzes.map((quiz, i) => (
                                <QuizCard key={quiz.id} quiz={quiz} index={i} />
                            ))}
                        </motion.div>
                        {availableQuizzes.length === 0 && <p className="text-center text-muted-foreground mt-10">No new quizzes available. Great job staying on top of things!</p>}
                    </TabsContent>
                    
                    <TabsContent value="in-progress">
                        <motion.div
                            variants={containerVariants}
                            initial="hidden"
                            animate="visible"
                            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6"
                        >
                            {inProgressQuizzes.map((quiz, i) => (
                                <QuizCard key={quiz.id} quiz={quiz} index={i} />
                            ))}
                        </motion.div>
                        {inProgressQuizzes.length === 0 && <p className="text-center text-muted-foreground mt-10">No quizzes in progress. Start one from the "Available" tab!</p>}
                    </TabsContent>

                    <TabsContent value="completed">
                        <motion.div
                            variants={containerVariants}
                            initial="hidden"
                            animate="visible"
                            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6"
                        >
                            {completedQuizzes.map((quiz, i) => (
                                <QuizCard key={quiz.id} quiz={quiz} index={i} />
                            ))}
                        </motion.div>
                         {completedQuizzes.length === 0 && <p className="text-center text-muted-foreground mt-10">No quizzes completed yet. Keep learning and testing your skills!</p>}
                    </TabsContent>
                </Tabs>
            </div>
        </>
    );
};

export default QuizzesPage;