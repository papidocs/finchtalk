import React from 'react';
import { useTheme } from '@/context/ThemeContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Sun, Moon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Helmet } from 'react-helmet';

const Appearance = () => {
  const { theme, setTheme } = useTheme();

  return (
    <>
      <Helmet>
        <title>Appearance | Finchtalk</title>
        <meta name="description" content="Customize the look and feel of your Finchtalk experience." />
      </Helmet>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Appearance</h1>
          <p className="text-muted-foreground">
            Customize the look and feel. Choose between light and dark mode.
          </p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Theme</CardTitle>
            <CardDescription>Select a theme for the dashboard.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div
                className={cn(
                  'cursor-pointer rounded-lg border-2 p-4',
                  theme === 'light' ? 'border-primary' : 'border-muted'
                )}
                onClick={() => setTheme('light')}
              >
                <div className="space-y-2">
                  <div className="flex items-center gap-2 font-semibold">
                    <Sun className="h-5 w-5" />
                    Light
                  </div>
                  <div className="aspect-video rounded-lg bg-[#ecedef] p-2">
                    <div className="w-full rounded-md bg-white p-2 shadow-sm">
                      <div className="h-2 w-full rounded-lg bg-[#ecedef]" />
                      <div className="mt-2 h-2 w-4/5 rounded-lg bg-[#ecedef]" />
                    </div>
                  </div>
                </div>
              </div>
              <div
                className={cn(
                  'cursor-pointer rounded-lg border-2 p-4',
                  theme === 'dark' ? 'border-primary' : 'border-muted'
                )}
                onClick={() => setTheme('dark')}
              >
                <div className="space-y-2">
                  <div className="flex items-center gap-2 font-semibold">
                    <Moon className="h-5 w-5" />
                    Dark
                  </div>
                  <div className="aspect-video rounded-lg bg-[#09090b] p-2">
                    <div className="w-full rounded-md bg-[#1c1917] p-2 shadow-sm">
                      <div className="h-2 w-full rounded-lg bg-[#44403c]" />
                      <div className="mt-2 h-2 w-4/5 rounded-lg bg-[#44403c]" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default Appearance;