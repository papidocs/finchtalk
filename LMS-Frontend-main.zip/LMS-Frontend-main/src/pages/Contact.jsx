import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { Mail, MessageCircle, Phone } from 'lucide-react';

const Contact = () => {
  const { toast } = useToast();

  const handleWhatsApp = () => {
    window.open('https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20help%20choosing%20a%20course%20and%20booking%20a%20demo.', '_blank');
  };
  
  const handleDemo = () => {
     window.open('https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20to%20book%20a%20live%20demo.', '_blank');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: 'Message Sent!',
      description: "Thanks for reaching out. We'll get back to you shortly.",
    });
    e.target.reset();
  };

  return (
    <>
      <Helmet>
        <title>Contact Us — Get Support or Book a Demo | Finchtalk</title>
        <meta name="description" content="Reach out to the Finchtalk team via our contact form, WhatsApp, or book a live demo to see our platform in action." />
      </Helmet>
      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-semibold mb-4">Get in Touch</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We're here to help! Whether you have a question about a course or want a demo, feel free to reach out.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <h2 className="text-2xl font-semibold mb-6">Contact Form</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input type="text" placeholder="Your Name" required />
                <Input type="email" placeholder="Your Email" required />
                <Textarea placeholder="Your Message" rows={5} required />
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90">Send Message</Button>
              </form>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-8"
            >
              <div>
                <h2 className="text-2xl font-semibold mb-4">Other Ways to Connect</h2>
                <div className="space-y-4">
                  <Button onClick={handleWhatsApp} variant="outline" className="w-full justify-start text-left h-auto py-3">
                    <MessageCircle className="w-6 h-6 mr-4 text-primary" />
                    <div>
                      <p className="font-semibold">Chat on WhatsApp</p>
                      <p className="text-sm text-muted-foreground">For quick questions and support.</p>
                    </div>
                  </Button>
                  <div className="p-4 bg-secondary/30 border border-border rounded-lg text-center">
                    <p className="font-semibold mb-2">Prefer a call? Book a demo.</p>
                    <p className="text-sm text-muted-foreground mb-3">Our AI assistant will schedule a Zoom call with you.</p>
                    <Button onClick={handleDemo} size="sm">
                       <Phone className="w-4 h-4 mr-2" /> Book a Demo Call
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;