import React from 'react';
import { Helmet } from 'react-helmet';
import Hero from '@/components/home/Hero';
import Band2 from '@/components/home/Band2';
import Band3 from '@/components/home/Band3';
import HowItWorks from '@/components/home/HowItWorks';
import WhyFinchtalk from '@/components/home/WhyFinchtalk';
import BookDemo from '@/components/home/BookDemo';

const Home = () => {
  return (
    <>
      <Helmet>
        <title>Finchtalk: IT Training & Support — Live Zoom Classes, Recordings & Cloud Labs</title>
        <meta name="description" content="Learn IT, Cloud, and Data the practical way. Live Zoom sessions, recordings, and hands-on labs. Chat to book a live demo and explore courses & workshops." />
        <meta property="og:title" content="Finchtalk — Practical IT Training & Support" />
        <meta property="og:description" content="Live classes, recordings, labs, and 1:1 SME support." />
      </Helmet>
      
      <div className="pt-16 md:pt-20">
        <Hero />
        <Band2 />
        <Band3 />
        <HowItWorks />
        <WhyFinchtalk />
        <BookDemo />
      </div>
    </>
  );
};

export default Home;