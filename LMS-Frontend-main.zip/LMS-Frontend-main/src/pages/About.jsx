import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Zap, Users, Shield, Target } from 'lucide-react';

const About = () => {
  const team = [
    { name: 'Alex Johnson', role: 'Founder & Lead Instructor', image: 'https://i.pravatar.cc/150?img=1' },
    { name: 'Maria Garcia', role: 'Head of Curriculum', image: 'https://i.pravatar.cc/150?img=2' },
    { name: 'Sam Chen', role: 'DevOps & Cloud Expert', image: 'https://i.pravatar.cc/150?img=3' },
  ];

  return (
    <>
      <Helmet>
        <title>About Finchtalk — Our Mission & Team</title>
        <meta name="description" content="Learn about Finchtalk's mission to make IT training practical and accessible through live instruction and hands-on labs." />
      </Helmet>
      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-semibold mb-4">About Finchtalk</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We're on a mission to bridge the gap between theory and practice in IT education, empowering professionals with the skills they need to succeed.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <Target className="w-12 h-12 mx-auto text-primary mb-4"/>
              <h3 className="text-xl font-semibold mb-2">Our Mission</h3>
              <p className="text-muted-foreground">To provide practical, accessible, and engaging IT training that delivers real-world results.</p>
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <Zap className="w-12 h-12 mx-auto text-primary mb-4"/>
              <h3 className="text-xl font-semibold mb-2">Our Approach</h3>
              <p className="text-muted-foreground">We believe in learning by doing. Our lab-first method ensures you gain hands-on experience.</p>
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
              <Shield className="w-12 h-12 mx-auto text-primary mb-4"/>
              <h3 className="text-xl font-semibold mb-2">Our Values</h3>
              <p className="text-muted-foreground">Commitment to quality, student success, and continuous improvement.</p>
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-semibold mb-4">Meet the Team</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our instructors are industry experts passionate about sharing their knowledge.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className="text-center"
              >
                <img src={member.image} alt={`Finchtalk trainer ${member.name}`} className="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-primary/50"/>
                <h4 className="text-xl font-semibold">{member.name}</h4>
                <p className="text-muted-foreground">{member.role}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default About;