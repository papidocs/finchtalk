import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/context/AuthContext';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from '@/components/ui/use-toast';
import { useLocation } from 'react-router-dom';

const Profile = () => {
    const { user } = useAuth();
    const { toast } = useToast();
    const location = useLocation();
    const isInstructorView = location.pathname.startsWith('/instructor') || location.pathname.startsWith('/settings');

    const getInitials = (name = '') => name?.split(' ').map(n => n[0]).join('') || '';

    const handleSubmit = (e) => {
        e.preventDefault();
        toast({
          title: 'Profile Updated',
          description: "Your changes have been saved successfully.",
        });
    }

    const InstructorProfileFields = () => (
      <>
        <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Input id="bio" placeholder="Your short professional bio" />
        </div>
        <div className="space-y-2">
            <Label htmlFor="expertise">Expertise</Label>
            <Input id="expertise" placeholder="e.g., Cloud, DevOps, Data Science" />
        </div>
      </>
    );

    return (
        <>
            <Helmet>
                <title>My Profile | Finchtalk</title>
            </Helmet>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-2xl"
            >
                <h1 className="text-3xl font-bold mb-6">My Profile</h1>
                <div className="flex flex-col items-center mb-8 bg-card border rounded-lg p-6">
                    <Avatar className="h-24 w-24 mb-4">
                        <AvatarImage src={`https://i.pravatar.cc/150?u=${user.id}`} alt={user.name} />
                        <AvatarFallback className="text-3xl">{getInitials(user.name)}</AvatarFallback>
                    </Avatar>
                    <h2 className="text-2xl font-semibold">{user.name}</h2>
                    <p className="text-muted-foreground capitalize">{user.role}</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6 bg-card border border-border p-8 rounded-lg">
                    <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input id="name" defaultValue={user.name} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" defaultValue={user.email} disabled />
                    </div>
                    
                    {isInstructorView && <InstructorProfileFields />}

                    <div className="space-y-2">
                        <Label htmlFor="password">New Password</Label>
                        <Input id="password" type="password" placeholder="Leave blank to keep current password" />
                    </div>
                    <Button type="submit" className="w-full">Save Changes</Button>
                </form>
            </motion.div>
        </>
    );
};

export default Profile;