import React, { useState, useMemo, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Search, Filter, X, ListFilter, LayoutGrid } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { getMockCourses } from '@/lib/mockApi';
import { useQueryParams } from '@/hooks/useQueryParams';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

const CourseCard = ({ course }) => (
  <Link to={`/course/${course.slug}`} className="block group">
    <div className="bg-card border border-border rounded-xl overflow-hidden h-full flex flex-col transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <div className="aspect-video bg-muted overflow-hidden">
        <img
          class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          alt={course.title}
         src="https://images.unsplash.com/photo-1650234083177-871b96b6c575" />
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs font-semibold px-2 py-0.5 bg-primary/10 text-primary rounded-full">{course.level}</span>
          <span className="text-xs font-semibold px-2 py-0.5 bg-secondary text-secondary-foreground rounded-full">{course.category}</span>
        </div>
        <h3 className="font-semibold text-lg flex-grow">{course.title}</h3>
        <div className="flex items-center justify-between text-sm text-muted-foreground mt-4">
          <span>{course.duration}</span>
          <span className="font-medium text-foreground">View Details &rarr;</span>
        </div>
      </div>
    </div>
  </Link>
);

const BrowseCourses = () => {
  const { getQueryParams, setQueryParams } = useQueryParams();
  const allCourses = useMemo(() => getMockCourses(), []);

  const [filters, setFilters] = useState(() => {
    const params = getQueryParams();
    return {
      query: params.get('query') || '',
      sort: params.get('sort') || 'newest',
      level: params.getAll('level') || [],
      category: params.getAll('category') || [],
      duration: params.getAll('duration') || [],
    };
  });

  useEffect(() => {
    const params = {};
    if (filters.query) params.query = filters.query;
    if (filters.sort !== 'newest') params.sort = filters.sort;
    if (filters.level.length > 0) params.level = filters.level;
    if (filters.category.length > 0) params.category = filters.category;
    if (filters.duration.length > 0) params.duration = filters.duration;
    
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        value.forEach(v => searchParams.append(key, v));
      } else {
        searchParams.set(key, value);
      }
    });
    
    window.history.replaceState(null, '', `?${searchParams.toString()}`);
  }, [filters]);

  const handleFilterChange = (group, value) => {
    setFilters(prev => {
      const currentGroup = prev[group] || [];
      const newGroup = currentGroup.includes(value)
        ? currentGroup.filter(item => item !== value)
        : [...currentGroup, value];
      return { ...prev, [group]: newGroup };
    });
  };

  const filteredCourses = useMemo(() => {
    let courses = [...allCourses];

    if (filters.query) {
      courses = courses.filter(c => c.title.toLowerCase().includes(filters.query.toLowerCase()));
    }
    if (filters.level.length > 0) {
      courses = courses.filter(c => filters.level.includes(c.level));
    }
    if (filters.category.length > 0) {
      courses = courses.filter(c => filters.category.includes(c.category));
    }
    if (filters.duration.length > 0) {
      courses = courses.filter(c => {
        const weeks = parseInt(c.duration);
        return filters.duration.some(d => {
          if (d === 'short') return weeks <= 4;
          if (d === 'medium') return weeks > 4 && weeks <= 8;
          if (d === 'long') return weeks > 8;
          return false;
        });
      });
    }

    if (filters.sort === 'popular') {
      // Mock popularity sort
      courses.sort((a, b) => (b.id.charCodeAt(0) % 5) - (a.id.charCodeAt(0) % 5));
    } else { // newest
      courses.sort((a, b) => b.id.localeCompare(a.id));
    }

    return courses;
  }, [filters, allCourses]);

  const filterOptions = {
    level: ['Beginner', 'Intermediate', 'Advanced'],
    category: [...new Set(allCourses.map(c => c.category))],
    duration: [
      { value: 'short', label: 'Under 4 weeks' },
      { value: 'medium', label: '4-8 weeks' },
      { value: 'long', label: 'Over 8 weeks' },
    ],
  };

  const FilterSidebar = () => (
    <aside className="w-full lg:w-72 lg:flex-shrink-0 space-y-6">
      <h2 className="text-xl font-bold flex items-center"><ListFilter className="mr-2 h-5 w-5" /> Filters</h2>
      <Accordion type="multiple" defaultValue={['level', 'category', 'duration']} className="w-full">
        <AccordionItem value="level">
          <AccordionTrigger>Level</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {filterOptions.level.map(level => (
                <div key={level} className="flex items-center space-x-2">
                  <Checkbox id={`level-${level}`} checked={filters.level.includes(level)} onCheckedChange={() => handleFilterChange('level', level)} />
                  <Label htmlFor={`level-${level}`}>{level}</Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
        <AccordionItem value="category">
          <AccordionTrigger>Category</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {filterOptions.category.map(cat => (
                <div key={cat} className="flex items-center space-x-2">
                  <Checkbox id={`cat-${cat}`} checked={filters.category.includes(cat)} onCheckedChange={() => handleFilterChange('category', cat)} />
                  <Label htmlFor={`cat-${cat}`}>{cat}</Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
        <AccordionItem value="duration">
          <AccordionTrigger>Duration</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {filterOptions.duration.map(dur => (
                <div key={dur.value} className="flex items-center space-x-2">
                  <Checkbox id={`dur-${dur.value}`} checked={filters.duration.includes(dur.value)} onCheckedChange={() => handleFilterChange('duration', dur.value)} />
                  <Label htmlFor={`dur-${dur.value}`}>{dur.label}</Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </aside>
  );

  return (
    <>
      <Helmet>
        <title>Browse All Courses | Finchtalk</title>
        <meta name="description" content="Search, filter, and browse our entire catalog of expert-led IT courses." />
      </Helmet>
      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-semibold mb-4">Browse All Courses</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Find your next learning opportunity.</p>
          </motion.div>

          <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
            <div className="lg:sticky top-24 h-fit">
              <FilterSidebar />
            </div>

            <main className="flex-1">
              <div className="flex flex-col md:flex-row gap-4 justify-between items-center mb-6">
                <div className="relative w-full md:max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search courses..."
                    value={filters.query}
                    onChange={(e) => setFilters(f => ({ ...f, query: e.target.value }))}
                    className="w-full pl-10 pr-4 py-2"
                  />
                </div>
                <div className="flex items-center gap-4">
                  <Select value={filters.sort} onValueChange={(value) => setFilters(f => ({ ...f, sort: value }))}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">Newest</SelectItem>
                      <SelectItem value="popular">Popular</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="border-t border-border pt-6">
                <p className="text-sm text-muted-foreground mb-6">{filteredCourses.length} results found</p>
                {filteredCourses.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                    {filteredCourses.map((course) => (
                      <CourseCard key={course.id} course={course} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-20 border border-dashed rounded-lg">
                    <LayoutGrid className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No Courses Found</h3>
                    <p className="text-muted-foreground">Try adjusting your search or filters.</p>
                  </div>
                )}
              </div>
            </main>
          </div>
        </div>
      </div>
    </>
  );
};

export default BrowseCourses;