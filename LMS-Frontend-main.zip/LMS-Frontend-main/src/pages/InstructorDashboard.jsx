// This file is now empty as the instructor dashboard is a layout.
// I will keep it but make it empty to avoid errors
// In a real application, this could be a page with stats for instructors.
import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/context/AuthContext';
import { motion } from 'framer-motion';

const InstructorDashboard = () => {
    const { user } = useAuth();
    return (
        <>
            <Helmet>
                <title>Instructor Home | Finchtalk</title>
            </Helmet>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
                <h1 className="text-4xl font-semibold">Instructor Hub</h1>
                <p className="text-muted-foreground text-lg">Welcome, {user.name}. Manage your courses and students.</p>
            </motion.div>
        </>
    )
}

export default InstructorDashboard;