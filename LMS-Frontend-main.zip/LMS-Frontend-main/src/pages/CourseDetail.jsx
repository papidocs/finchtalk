import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Clock, User, Video, Calendar, CheckCircle, MessageCircle } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const CourseDetail = () => {
  const { slug } = useParams();

  // ==== YOUR ORIGINAL DATA (unchanged) + optional demos ====
  const allCoursesData = {
    'aws-cloud-practitioner': {
      title: 'AWS Cloud Practitioner',
      domain: 'Cloud',
      level: 'Beginner',
      duration: '4 weeks',
      trainer: 'Sarah Johnson',
      trainerBio: 'AWS Certified Solutions Architect with 8+ years of cloud experience',
      description: 'Master AWS fundamentals and prepare for the Cloud Practitioner certification with hands-on labs and real-world scenarios.',
      learningOutcomes: [
        'Understand AWS global infrastructure and core services',
        'Learn cloud computing concepts and deployment models',
        'Master AWS pricing, billing, and support plans',
        'Prepare for AWS Cloud Practitioner certification exam',
        'Build and deploy applications on AWS'
      ],
      syllabus: [
        'Introduction to Cloud Computing',
        'AWS Global Infrastructure',
        'Core AWS Services (EC2, S3, RDS)',
        'Security and Compliance',
        'Pricing and Billing',
        'Exam Preparation'
      ],
      schedule: 'Tuesdays & Thursdays, 7:00 PM - 9:00 PM IST',
      // NEW: optional demos list (add/remove as you like)
      demos: [
        {
          instructor: 'Anil (AWS Pro)',
          headline: 'AWS Foundations overview',
          // YouTube embed example – replace with your URL or Vimeo etc.
          videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ?rel=0',
          isDefault: true
        },
        {
          instructor: 'Meera (AWS Architect)',
          headline: 'Hands-on with S3 + IAM',
          videoUrl: 'https://www.youtube.com/embed/oHg5SJYRHA0?rel=0'
        }
      ]
    },

    // ==== keep your other courses as-is; you can add demos[] later if needed ====
    'devops-docker-kubernetes': {
      title: 'DevOps with Docker & Kubernetes',
      domain: 'DevOps',
      level: 'Intermediate',
      duration: '6 weeks',
      trainer: 'Mike Chen',
      trainerBio: 'Certified Kubernetes Administrator with a passion for automation.',
      description: 'Learn containerization and orchestration with hands-on projects, building scalable and resilient applications.',
      learningOutcomes: [
        'Containerize applications using Docker',
        'Manage multi-container applications with Docker Compose',
        'Orchestrate containers with Kubernetes',
        'Implement CI/CD pipelines for containerized apps',
        'Monitor and manage Kubernetes clusters'
      ],
      syllabus: [
        'Introduction to DevOps and Containers',
        'Docker Fundamentals',
        'Kubernetes Architecture',
        'Deploying Applications on Kubernetes',
        'Advanced Kubernetes Concepts',
        'CI/CD with Jenkins and Kubernetes'
      ],
      schedule: 'Mondays & Wednesdays, 8:00 PM - 10:00 PM IST'
    },

    'data-engineering-fundamentals': {
      title: 'Data Engineering Fundamentals',
      domain: 'Data',
      level: 'Beginner',
      duration: '5 weeks',
      trainer: 'Priya Sharma',
      trainerBio: 'Data Engineer with expertise in building large-scale data pipelines.',
      description: 'Build data pipelines and learn modern data engineering practices, including ETL, data warehousing, and big data technologies.',
      learningOutcomes: [
        'Understand the data engineering lifecycle',
        'Build ETL/ELT pipelines with Python and Airflow',
        'Work with SQL and NoSQL databases',
        'Introduction to data warehousing with Snowflake',
        'Basics of Spark for big data processing'
      ],
      syllabus: [
        'The Role of a Data Engineer',
        'Data Modeling and Warehousing',
        'Building Batch Data Pipelines',
        'Introduction to Streaming Data',
        'Data Governance and Quality',
        'Capstone Project'
      ],
      schedule: 'Saturdays, 10:00 AM - 1:00 PM IST'
    }
  };

  const course = allCoursesData[slug] || allCoursesData['aws-cloud-practitioner'];

  // ==== NEW: minimal state for the video session ====
  const demos = course.demos || [];
  const defaultDemoIndex = Math.max(0, demos.findIndex(d => d.isDefault));
  const [activeDemoIndex, setActiveDemoIndex] = useState(defaultDemoIndex);

  const activeDemo = demos[activeDemoIndex];

  const handleRequestDemo = () => {
    window.open(
      'https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20help%20choosing%20a%20course%20and%20booking%20a%20demo.',
      '_blank'
    );
  };

  const handleWhatsApp = () => {
    window.open(
      'https://wa.me/?text=Hi%20Finchtalk%E2%80%94I%27d%20like%20help%20choosing%20a%20course%20and%20booking%20a%20demo.',
      '_blank'
    );
  };

  return (
    <>
      <Helmet>
        <title>{course.title} — Live Zoom + Recording | Finchtalk</title>
        <meta
          name="description"
          content={`Learn ${course.title}. Live Zoom sessions, recordings, and hands-on labs. Request a live demo now.`}
        />
      </Helmet>

      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
              <div className="flex flex-wrap gap-2 mb-4">
                <span className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">{course.domain}</span>
                <span className="px-3 py-1 bg-secondary text-muted-foreground text-sm rounded-full">{course.level}</span>
              </div>

              <h1 className="text-4xl md:text-5xl font-semibold mb-4">{course.title}</h1>
              <p className="text-lg text-muted-foreground mb-6">{course.description}</p>

              <div className="flex flex-wrap gap-6 mb-6">
                <div className="flex items-center text-muted-foreground">
                  <Clock className="w-5 h-5 mr-2 text-primary" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <User className="w-5 h-5 mr-2 text-primary" />
                  <span>{course.trainer}</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Video className="w-5 h-5 mr-2 text-primary" />
                  <span>Recording Available</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Calendar className="w-5 h-5 mr-2 text-primary" />
                  <span>{course.schedule}</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button onClick={handleRequestDemo} size="lg" className="bg-primary hover:bg-primary/90">
                  Request a Live Demo
                </Button>
                <Button onClick={handleWhatsApp} size="lg" variant="outline">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Chat on WhatsApp
                </Button>
              </div>
            </motion.div>

            {/* ==== NEW: Video Session (only renders if demos exist) ==== */}
            {demos.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="mb-10"
              >
                <div className="mb-4 flex flex-wrap gap-3">
                  {demos.map((d, i) => {
                    const active = i === activeDemoIndex;
                    return (
                      <button
                        key={`${d.instructor}-${i}`}
                        onClick={() => setActiveDemoIndex(i)}
                        className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-sm transition ${
                          active ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary font-semibold">
                          {d.instructor.split(' ').map((n) => n[0]).join('')}
                        </span>
                        <div className="text-left">
                          <div className="font-medium">{d.instructor}</div>
                          {d.headline && <div className="text-xs text-muted-foreground">{d.headline}</div>}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {activeDemo && (
                  <div className="aspect-video w-full overflow-hidden rounded-xl border border-border bg-black">
                    <iframe
                      width="100%"
                      height="100%"
                      src={activeDemo.videoUrl}
                      title={activeDemo.instructor + ' — Demo'}
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                )}
              </motion.div>
            )}
            {/* ==== END Video Session ==== */}

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="learning">What You'll Learn</TabsTrigger>
                  <TabsTrigger value="syllabus">Syllabus</TabsTrigger>
                  <TabsTrigger value="trainer">Trainer</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="mt-6">
                  <div className="bg-card border border-border rounded-xl p-6">
                    <h3 className="text-2xl font-semibold mb-4">Course Overview</h3>
                    <p className="text-muted-foreground mb-6">{course.description}</p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-secondary/50 rounded-lg p-4">
                        <h4 className="font-semibold mb-2">Duration</h4>
                        <p className="text-muted-foreground">{course.duration}</p>
                      </div>
                      <div className="bg-secondary/50 rounded-lg p-4">
                        <h4 className="font-semibold mb-2">Level</h4>
                        <p className="text-muted-foreground">{course.level}</p>
                      </div>
                      <div className="bg-secondary/50 rounded-lg p-4">
                        <h4 className="font-semibold mb-2">Schedule</h4>
                        <p className="text-muted-foreground">{course.schedule}</p>
                      </div>
                      <div className="bg-secondary/50 rounded-lg p-4">
                        <h4 className="font-semibold mb-2">Format</h4>
                        <p className="text-muted-foreground">Live Zoom + Recordings</p>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="learning" className="mt-6">
                  <div className="bg-card border border-border rounded-xl p-6">
                    <h3 className="text-2xl font-semibold mb-4">What You'll Learn</h3>
                    <div className="space-y-3">
                      {course.learningOutcomes.map((outcome, index) => (
                        <div key={index} className="flex items-start space-x-3">
                          <CheckCircle className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                          <span className="text-muted-foreground">{outcome}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="syllabus" className="mt-6">
                  <div className="bg-card border border-border rounded-xl p-6">
                    <h3 className="text-2xl font-semibold mb-4">Syllabus Highlights</h3>
                    <div className="space-y-3">
                      {course.syllabus.map((topic, index) => (
                        <div key={index} className="flex items-center space-x-3 p-3 bg-secondary/50 rounded-lg">
                          <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-semibold text-sm">
                            {index + 1}
                          </div>
                          <span>{topic}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="trainer" className="mt-6">
                  <div className="bg-card border border-border rounded-xl p-6">
                    <h3 className="text-2xl font-semibold mb-4">Your Trainer</h3>
                    <div className="flex items-start space-x-4">
                      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-2xl font-semibold text-white">
                        {course.trainer.split(' ').map((n) => n[0]).join('')}
                      </div>
                      <div>
                        <h4 className="text-xl font-semibold mb-2">{course.trainer}</h4>
                        <p className="text-muted-foreground">{course.trainerBio}</p>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CourseDetail;