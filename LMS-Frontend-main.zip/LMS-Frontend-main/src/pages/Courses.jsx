import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Search, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { getMockCourses } from '@/lib/mockApi';
import CourseCard from '@/components/courses/CourseCard';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';

const Courses = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    domain: 'all',
    level: 'all',
    duration: 'all'
  });
  
  const allCourses = getMockCourses();
  
  const domains = ['all', ...new Set(allCourses.map(c => c.category))];
  const levels = ['all', ...new Set(allCourses.map(c => c.level))];
  const durations = ['all', ...new Set(allCourses.map(c => c.duration))];

  const filteredCourses = allCourses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.summary.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDomain = filters.domain === 'all' || course.category === filters.domain;
    const matchesLevel = filters.level === 'all' || course.level === filters.level;
    const matchesDuration = filters.duration === 'all' || course.duration === filters.duration;
    
    return matchesSearch && matchesDomain && matchesLevel && matchesDuration;
  });

  return (
    <>
      <Helmet>
        <title>Course Catalogue | Finchtalk</title>
        <meta name="description" content="Browse our catalog of IT, Cloud, DevOps, and Data courses. Live Zoom sessions, recordings, and hands-on labs. Request a demo today." />
      </Helmet>

      <div className="pt-28 md:pt-36 pb-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-semibold mb-4">Course Catalogue</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Explore our comprehensive collection of IT training courses
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto mb-8 space-y-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search courses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-card border border-border rounded-lg text-base h-12"
              />
            </div>
            
            <div className="bg-card border border-border rounded-xl p-4 md:p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Select value={filters.domain} onValueChange={(value) => setFilters(f => ({ ...f, domain: value }))}>
                  <SelectTrigger className="h-12 text-base">
                    <SelectValue placeholder="All Domains" />
                  </SelectTrigger>
                  <SelectContent>
                    {domains.map(domain => <SelectItem key={domain} value={domain}>{domain === 'all' ? 'All Domains' : domain}</SelectItem>)}
                  </SelectContent>
                </Select>
                 <Select value={filters.level} onValueChange={(value) => setFilters(f => ({ ...f, level: value }))}>
                  <SelectTrigger className="h-12 text-base">
                    <SelectValue placeholder="All Levels" />
                  </SelectTrigger>
                  <SelectContent>
                    {levels.map(level => <SelectItem key={level} value={level}>{level === 'all' ? 'All Levels' : level}</SelectItem>)}
                  </SelectContent>
                </Select>
                 <Select value={filters.duration} onValueChange={(value) => setFilters(f => ({ ...f, duration: value }))}>
                  <SelectTrigger className="h-12 text-base">
                    <SelectValue placeholder="All Durations" />
                  </SelectTrigger>
                  <SelectContent>
                    {durations.map(duration => <SelectItem key={duration} value={duration}>{duration === 'all' ? 'All Durations' : duration}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
            {filteredCourses.map((course, index) => (
              <CourseCard key={course.id} course={course} index={index} />
            ))}
          </div>

          {filteredCourses.length === 0 && (
            <div className="text-center py-20 border-2 border-dashed border-border rounded-xl mt-12">
              <Filter className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Courses Found</h3>
              <p className="text-muted-foreground">Try adjusting your filters or search term.</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Courses;