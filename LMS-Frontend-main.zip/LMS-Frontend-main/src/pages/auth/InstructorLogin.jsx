
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';
import AuthLayout from '@/components/layout/AuthLayout';

const InstructorLogin = () => {
  const [email, setEmail] = useState('instructor@finchtalk.com');
  const [password, setPassword] = useState('password123');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await login(email, password, 'instructor'); // Specify intended role
      toast({
        title: "Welcome Back, Instructor!",
        description: "You've successfully signed in.",
      });
    } catch (err) {
      setError(err.message);
      toast({ variant: "destructive", title: "Login Failed", description: err.message });
    }
  };

  return (
    <>
      <Helmet>
        <title>Instructor Login | Finchtalk</title>
        <meta name="description" content="Instructor login for Finchtalk platform." />
      </Helmet>
      <AuthLayout
        title="Welcome back, Instructor"
        description="Sign in to manage your courses, learners, and sessions."
        footerText="Not an instructor?"
        footerLinkText="Student or Admin login"
        footerLinkTo="/login"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required placeholder="instructor@finchtalk.com" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required placeholder="password123" />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full bg-primary hover:bg-primary/90">Sign in</Button>
        </form>
        <p className="mt-4 text-center text-sm text-muted-foreground">
          Don't have an instructor account?{' '}
          <Link to="#" className="font-medium text-primary hover:underline" onClick={() => toast({title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"})}>
            Apply to teach
          </Link>
        </p>
      </AuthLayout>
    </>
  );
};

export default InstructorLogin;
