import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const Policies = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service | Finchtalk</title>
        <meta name="description" content="Read the Terms of Service for using Finchtalk's IT training platform and services." />
      </Helmet>
      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="prose prose-invert lg:prose-xl mx-auto"
          >
            <h1>Terms of Service</h1>
            <p className="lead">Last updated: November 2, 2025</p>
            <p>Welcome to Finchtalk! These terms and conditions outline the rules and regulations for the use of Finchtalk's Website, located at finchtalk.com.</p>
            <p>By accessing this website we assume you accept these terms and conditions. Do not continue to use Finchtalk if you do not agree to take all of the terms and conditions stated on this page.</p>

            <h2>1. License</h2>
            <p>Unless otherwise stated, Finchtalk and/or its licensors own the intellectual property rights for all material on Finchtalk. All intellectual property rights are reserved. You may access this from Finchtalk for your own personal use subjected to restrictions set in these terms and conditions.</p>
            <p>You must not:</p>
            <ul>
                <li>Republish material from Finchtalk</li>
                <li>Sell, rent or sub-license material from Finchtalk</li>
                <li>Reproduce, duplicate or copy material from Finchtalk</li>
                <li>Redistribute content from Finchtalk</li>
            </ul>

            <h2>2. User Accounts</h2>
            <p>When you create an account with us, you must provide us information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our Service.</p>

            <h2>3. Termination</h2>
            <p>We may terminate or suspend access to our Service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>
            
            <p><em>(This is a placeholder. A complete Terms of Service document is required for a live website.)</em></p>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default Policies;